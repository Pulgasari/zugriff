<?php
// Show Errors
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

// Server Lib Autoloader
require_once __DIR__ . '/../../lib/php/autoloader.php';

// WTF Configuration
WTF::config([
  'spinner'      => 'svg-spinners:bars-scale-middle',
  'browserCache' => false,
  'charset'      => 'UTF-8',
  'language'     => 'de',
  'name'         => 'Icons @ Ratcode',
  'themeColor'   => '#2ecc71',
  'title'        => 'Icons @ Ratcode',
  'url'          => 'https://icons.ratcode.dev/',
  'version'      => '1.0.0',
  'db' => [
    'name'     => '',
    'user'     => '',
    'password' => '',
  ],
  'css' => [
    'link' => [
      'app.css?v='.time()
    ],
  ],
  'js' => [
    'module' => [
      'app.js?v='.time()
    ],
    'script' => [
      'https://code.iconify.design/iconify-icon/3.0.0/iconify-icon.min.js'
    ],
  ]
]);

// Iconify Cache
$cache = new IconifyCache(__DIR__.'/../../cache/iconify/');
Iconify::setCache($cache);
IconifyAPI::setCache($cache);