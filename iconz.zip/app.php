<?php
require_once __DIR__ . '/config.php';

$path0 = WTF::url()->paths[0] ?? null;
$path1 = WTF::url()->paths[1] ?? null;

// --- Routing Logik ---
$page = match(true) {
  $path0 === 'favorites' => 'favorites',
  $path0 === 'sets'      => 'iconsets',
  $path0 === 'search'    => 'search',
  $path0 === 'test'      => 'test',
  $path0 && !$path1      => 'iconset',
  $path0 &&  $path1      => 'icon',
  default                => 'home',
};

// Dummy
$dummy = array_merge(
  getDummyIcons('lucide', 20), 
  getDummyIcons('mdi', 20), 
  getDummyIcons('ph', 10)
);


// --- Rendering ---
$url = WTF::url();
try {
  echo match ($page) {
    'favorites' => WTF::tmpl('favorites', ['icons' => $dummy]),
    'icon'      => WTF::tmpl('icon',      ['prefix' => $path0, 'iconName' => $path1]),
    'iconset'   => WTF::tmpl('iconset',   ['prefix' => $path0, 'iconset' => getIconset($path0)]),
    'iconsets'  => WTF::tmpl('iconsets',  ['iconsets' => getIconsets()]),
    'search'    => WTF::tmpl('search',    ['icons' => doSearch( $path1 ?: [] ), 'term' => ($path1 ?: '') ]),
    'test'      => include('./test.php'),
    default     => WTF::tmpl('home',      ['icons' => $dummy]),
  };
} catch (Exception $e) {
  echo "Fehler: " . $e->getMessage();
}

// --- Daten-Helfer ---
class CacheJSON {
  private string $dir;
  public function __construct( string $dir ){
    $this->dir = rtrim($dir, '/') . '/';
  }
  private function getPath( string $key ): string {
    if (!str_ends_with($key, '.json')) $key .= '.json';
    return $this->dir . $key;
  }
  public function exists( string $key ): bool {
    return file_exists($this->getPath($key));
  }
  public function load( string $key ) {
    $raw = file_get_contents($this->getPath($key));
    return json_decode($raw, true);
  }
  public function save( string $key, $data ): bool {
    if (!is_dir($this->dir)) mkdir($this->dir, 0777, true);
    $path = $this->getPath($key);
    $text = is_string($data) ? $data : json_encode($data);
    return file_put_contents($path, $text) !== false;
  }
}
function getIconset( string $slug ): iterable {
  return IconifyAPI::getIconset($slug);
}
function doSearch( mixed $term ) {
  if (!$term || !is_string($term)) return [];
  $data  = (object) IconifyAPI::search($term);
  $icons = $data->icons;
  return $icons;
}
function getIconsets(): array {
  $cache = new CacheJSON(__DIR__.'/cache/');
  
  // return from cache if it exists
  if ($cache->exists('iconsets')) return $cache->load('iconsets');
  
  // load from api
  $data = IconifyAPI::getCollections();
  $collections = $data['collections'] ?? $data; // Je nach API-Response
  $iconsets = [];
  foreach ($collections as $slug => $info) {
    $iconsets[] = ['slug' => $slug, ...$info];
  }
  
  // save to cache and return
  $cache->save('iconsets', $iconsets);
  return $iconsets;
}
function getDummyIcons( string $prefix = 'lucide', int $count = 50 ): array {
  $names = ['home', 'user', 'settings', 'search', 'check', 'heart', 'star', 'alert-circle', 'info', 'trash', 'edit', 'download', 'share', 'copy', 'menu', 'x', 'plus', 'minus', 'arrow-right', 'arrow-left', 'bell', 'calendar', 'camera', 'cloud', 'database', 'file', 'folder', 'image', 'mail', 'map-pin', 'phone', 'play', 'refresh-cw', 'save', 'shopping-cart', 'sun', 'moon', 'wifi', 'zap', 'monitor', 'smartphone', 'clock', 'lock', 'unlock', 'eye', 'eye-off', 'filter', 'link', 'hash', 'code'];
  $result = [];
  for ($i = 0; $i < $count; $i++) {
    $name = $names[$i % count($names)];
    $result[] = "$prefix:$name" . ($i > 49 ? "-$i" : "");
  }
  return $result;
}