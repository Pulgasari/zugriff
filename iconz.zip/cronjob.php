<?php
require_once __DIR__ . '/../../lib/php/autoloader.php';

// Konfiguration
define('DB_HOST', 'localhost');
define('DB_NAME', 'iconlib');
define('DB_USER', 'root');
define('DB_PASS', '');

if (($_GET['run'] ?? '') === 'true') {
  try {
    echo "Hole Collections von Iconify...\n";
    $apiData = IconifyAPI::getCollections();
    
    foreach ($apiData['collections'] as $prefix => $info) {
      // 1. Lokalen Status prüfen
      $res            = DB::query("SELECT last_modified_api FROM collections WHERE prefix = ?", [$prefix]);
      $local          = $res->fetch_assoc();
      $remoteModified = (int)( $info['lastModified']       ?? 0 );
      $localModified  = (int)( $local['last_modified_api'] ?? 0 );
      
      // 2. Collection Basis-Daten aktualisieren
      DB::upsert(
        table: 'collections',
        data: [
          'prefix'            => $prefix,
          'name'              => $info['name'],
          'author_name'       => $info['author']['name'] ?? 'Unknown',
          'author_url'        => $info['author']['url']  ?? null,
          'total'             => (int) ($info['total']   ?? 0),
          'last_modified_api' => $remoteModified
        ],
        updateFields: ['name', 'author_name', 'author_url', 'total', 'last_modified_api']
      );
      
      // 3. Wenn die API ein neueres Datum meldet -> Alle Icons des Sets laden
      if ($remoteModified > $localModified) {
        echo "Update für [$prefix] gefunden. Lade Icons...\n";
        $data  = (object) IconifyAPI::getCollection($prefix);
        $icons = array_keys($data->icons) ?? null;
        if ($icons) {
          foreach ($icons as $name) {
            DB::upsert(
              table : 'icons',
              data  : [ 'iconset' => $prefix, 'name' => $name ],
              updateFields: ['name'] // Sorgt nur dafür, dass der Constraint nicht bricht
            );
          }
          echo " -> " . count($icons) . " Icons aktualisiert.\n";
        }
      }
    }
    echo "\nCronjob erfolgreich beendet.\n";

  } catch (Exception $e) {
    echo "Fehler: " . $e->getMessage() . "\n";
  }
}