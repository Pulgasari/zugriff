const CACHE = 'pwa-cache-v1';
const ASSETS = ['./', './index.php', './manifest.json'];
self.addEventListener('install', e => {
e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
self.skipWaiting();
});
self.addEventListener('fetch', e => {
e.respondWith(fetch(e.request).catch(() => caches.match(e.request)));
});