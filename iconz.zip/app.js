import { dom }                       from 'https://cdn.ratcode.dev/js/ratlib.js';
import { $app, $body, $head, $root } from 'https://cdn.ratcode.dev/js/dom.js';
import { isFn }                      from 'https://cdn.ratcode.dev/js/is.js';
import { resizable }                 from 'https://cdn.ratcode.dev/js/elma.js';
import { watch }                     from 'https://cdn.ratcode.dev/js/observer.js';
import { debounce, onEvent }         from 'https://cdn.ratcode.dev/js/util.js';
import { hyperfetch, useNavigator }  from 'https://cdn.ratcode.dev/js/hyperfetch.js';
import { BunkerDB }                  from 'https://cdn.ratcode.dev/js/bunker.js';

// move to utils ???
let copyToClipboard = async text => {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (err) {
    console.error('Copy failed', err);
    return false;
  }
};

// Database
let db = new BunkerDB('IconApp');

// HyperSearch
let handleSearch = event => {
  let url   = 'https://icons.ratcode.dev/search/';
  let value = event.target.value;
  if (value) url += `${value.toLowerCase()}/`;
  hyperfetch({ url, selectors: ['main .grid', '#search', 'title'], mode: 'inner', clear: true });
};
let debouncedSearch = debounce(handleSearch, 250);
onEvent('input[name="search"]', 'input', debouncedSearch);

// HyperNavigate
let transition = {
  container : dom.createElement('div', 
    {style: {
      background     : 'var(--bg)',
      color          : 'var(--fg)',
      position       : 'fixed',
      inset          : '0',
      display        : 'flex',
      alignItems     : 'center',
      justifyContent : 'center',
      fontSize       : '256px',
      zIndex         : '9999',
    }},
    dom.createElement('span', { className: 'svg-spinners--bars-scale-middle' })
  ),
  onStart : () => $body.append(transition.container),
  onEnd   : () => transition?.container?.remove(),
};
useNavigator({ 
  clear     : true, 
  mode      : 'inner', 
  selectors : ['#app', 'title'], 
  transition
})

// Make Icons-Grid Resizable
let gridResizer = resizable( function( val, isFinal ){
  let value = Math.round(val);
  this.dataset.size = value;
  cookieStore.set('grid-item-size', value);
}, {
  min: 48,
  max: 256,
  setps: 12,
  //steps: [48, 64, 96, 128, 192, 256]
});
watch('.grid', { onAdd: el => dom.updateElement(el, gridResizer) });

// Fav
let Favs = {
  toggle : async (key) => await db.favs.toggle(key),
  isFav  : async (key) => await db.favs.has(key),
};
watch('.heart', {
  onAdd: async (el) => {
    let key = el.dataset.key;
    if (await Favs.isFav(key)) {
      el.classList.add('is-active');
      el.setAttribute('icon', 'bxs:heart');
    }
  }
});
window.wtf = {
  action: async (type, key, el) => {
    if (type === 'toggleHeart') {
      await Favs.toggle(key);
      let isFav = await Favs.isFav(key);
      let icon = isFav ? 'bxs:heart' : 'bx:heart';
      el.classList.toggle('is-active', isFav);
      el.setAttribute('icon', icon);
    }
  }
};

// AlphabetIndex
watch('.alphabet-index li', {
  onAdd: async (el) => {
    let handler = e => {
      console.log('[AlphabetIndex] click()');
      let value = e.currentTarget.textContent;
      dom.filterElements({
        container : '.iconsets',
        item      : '.item',
        filters   : [{ selector: '.name', mode: 'startsWith', value }]
      });
    };
    onEvent( el, 'click', handler );
  }
});