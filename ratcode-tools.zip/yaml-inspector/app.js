// yaml-inspector/app.js

import { render } from 'preact';
import { html } from 'htm/preact'; window.html = html;
import { DataInspectorApp } from 'tools';
import { parse, stringify } from 'yaml';
import hljs from 'highlight.js';
import yaml from 'highlight.js/languages/yaml';

hljs.registerLanguage('yaml', yaml);

let App = DataInspectorApp({
  appID       : 'yaml-inspector',
  lang        : 'yaml',
  placeholder : 'Paste YAML here …',
  parse       : src  => parse(src),
  format      : data => stringify(data),
  emptyIcon   : 'mdi:file-code-outline',
  emptyLabel  : 'Paste YAML and click Inspect',
});

render(html`<${App} />`, document.getElementById('app'));