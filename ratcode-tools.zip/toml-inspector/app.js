// toml-inspector/app.js

import { render } from 'preact';
import { html } from 'htm/preact'; window.html = html;
import { DataInspectorApp } from 'tools';
import { parse } from 'smol-toml';
import hljs from 'highlight.js';
import ini from 'highlight.js/languages/ini'; // has no TOML

hljs.registerLanguage('toml', ini);

let App = DataInspectorApp({
  appID       : 'toml-inspector',
  lang        : 'toml',
  placeholder : 'Paste TOML here …',
  parse       : src => parse(src),
  emptyIcon   : 'mdi:file-cog-outline',
  emptyLabel  : 'Paste TOML and click Inspect',
});

render(html`<${App} />`, document.getElementById('app'));