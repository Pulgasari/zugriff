[Diese File dient zur Information der LLM.]


Ich will auf meinem Webspace diverse PWA erstellen für nützliche Tools, die (meistens) offline funktionieren und als Android-Apps laufen sollen.

client-seitig: Preact/HTM, CSS, evtl. Webassembly
server-seitig: PHP

---

## Struktur

### Verzeichnisse

Pfad           | Beschreibung
---------------|----------------------
/.components   | Verzeichnis für wiederverwenbare Preact-Components
/.templates    | Verzeichnis für diverse Vorlagen

### Dateien

Pfad                      | Beschreibung
--------------------------|----------------------
/.templates/manifest.json | Vorlage für die automatisch generierte `manifest.json` einer App
/apps.json                | hier sind die infos über die apps / um apps die hier drin stehen wird sich anhand der meta-infos automatisch gekümmert (manifest.json oder icons generiert usw)
/global.css               | wird von jeder projekt/app.php eingebunden, provided gemeinsames css und diverse css-variablen wie --bg, --fg, --accent usw.
/global.js                | 
/global.php               | wird von jeder projekt/app.php included, provided einen autoloader für diverse libs aufm webspace

### Beispiel-Struktur für eine App

Pfad                         | Beschreibung
-----------------------------|----------------------
/example                     | Hauptverzeichnis einer App
/example/.htaccess           | 
/example/app.css             | 
/example/app.js              | Hauptdatei einer App
/example/app.php             | 
/example/app.svg             | aus dieser file werden die icons generiert (wenn sie vorhanden ist, sonst erstmal skip)
/example/manifest.json       | (wird generiert)
/example/assets/icon.svg     | (wird generiert)
/example/assets/icon-192.png | (wird generiert)
/example/assets/icon-512.png | (wird generiert)


---

## Infos zur Environment

- PHP-Version: 8.5

---

## Bestehende Components

- Dropzone
- Icon

---

## Apps

- [ ] Audio Converter
- [ ] Audio Cutter
- [ ] Base64 Decoder / Encoder
- [ ] CSS Minifier
- [ ] Domain Checker
- [ ] Image Converter
- [ ] JS Minifier
- [ ] JSON Converter -> to CSV, XML, TOML, YAML, INI
- [ ] JSON Formatter
- [ ] JSON Inspector
- [ ] JSON Minifier
- [ ] MD5 Hash Generator
- [ ] Password Generator
- [ ] UUID Generator
- [ ] Video Converter
- [ ] Video Cutter
- [ ] YAML Editor

GIF Creator
GIF Editor
Image Pixelater
JSON Validator

Domain Checker
Hash Generator (SHA-1, SHA-256, SHA-512, MD5, RIPEMD-160, Snefru, Ghost, Whirlpool)

- CSV Converter (to JSON, TOML, YAML, JavaScript Object)
- JSON Converter (to CSV, TOML, YAML, JavaScript Object)
- TOML Converter (to CSV, JSON, YAML, JavaScript Object)
- YAML Converter (to CSV, JSON, TOML, JavaScript Object)

https://www.minitools.app/de
https://onlinetools.com/json

---

Aktuelle /tools/apps.json:

[
{ "path": "convert-audio", "name": "Audio Converter" },
{ "path": "convert-img", "name": "Image Converter" },
{ "path": "convert-img-online", "name": "Image Converter (online)" }
]

Aktuelle /tools/manifest.json (Vorlage):

{
  "id"               : "{id}",
  "name"             : "{name}",
  "short_name"       : "{short_name}",
  "lang"             : "{lang}",
  "scope"            : "https://tools.pulgasari.dev/{path}/",
  "start_url"        : "/",
  "categories"       : ["converter"],
  "description"      : "{description}",
  "dir"              : "ltr",
  "display"          : "standalone",
  "orientation"      : "portrait",
  "background_color" : "#000000",
  "theme_color"      : "#000000",
  "icons": [
    {
      "src"   : "/assets/icon.svg",
      "sizes" : "any",
      "type"  : "image/svg+xml"
    },
    {
      "src"   : "/assets/icon-192.png",
      "sizes" : "192x192",
      "type"  : "image/png"
    },
    {
      "src"   : "/assets/icon-512.png",
      "sizes" : "512x512",
      "type"  : "image/png"
    }
  ]
}