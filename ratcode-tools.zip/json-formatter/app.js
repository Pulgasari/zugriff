import { render }  from 'preact';
import { signal }  from '@preact/signals';
import { html }    from 'htm/preact'; window.html = html;
import { Icon }    from 'tools';
import hljs        from 'highlight.js';
import json        from 'highlight.js/languages/json';
import { CodeInputPane, CodeOutputPane } from 'tools';
import { signalWithStorage } from 'preact-x';

hljs.registerLanguage('json', json);

let input  = signalWithStorage('', 'json-formatter:input');
let output = signal('');
let status = signal('idle');
let errMsg = signal('');
let indent = signal(2);

function doFormat() {
  let src = input.value.trim();
  if (!src) return;
  errMsg.value = '';
  try {
    output.value = JSON.stringify(JSON.parse(src), null, indent.value);
    status.value = 'done';
  } catch(e) {
    errMsg.value = e.message;
    status.value = 'error';
    output.value = '';
  }
}

let clear = () => { input.value = ''; output.value = ''; status.value = 'idle'; };

function IndentPicker() {
  return html`
    <div class="indent-picker">
      <span>Indent</span>
      ${[2, 4, '\t'].map(v => html`
        <button class=${'fmt-btn' + (indent.value === v ? ' active' : '')} onClick=${() => { indent.value = v; if (output.value) doFormat(); }}>
          ${v === '\t' ? 'tab' : v + ' spaces'}
        </button>`)}
    </div>`;
}

function App() {
  return html`
    <div id="app-body">
      <div class="panes">
        <${CodeInputPane}  lang='json' sig=${input} placeholder="Paste JSON here…" />
        <${CodeOutputPane} lang='json' sig=${output} status=${status} errMsg=${errMsg}  />
      </div>
      <div class="actions">
        <button class="btn primary" onClick=${doFormat} disabled=${!input.value}>
          <${Icon} name="mdi:auto-fix" /> Format
        </button>
        <${IndentPicker} />
        <button class="btn secondary" onClick=${clear} disabled=${!input.value}>
          <${Icon} name="mdi:close" /> Clear
        </button>
      </div>
    </div>`;
}

render(html`<${App} />`, document.getElementById('app'));