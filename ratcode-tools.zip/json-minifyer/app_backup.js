// json-minifyer/app.js

import { render }  from 'preact';
import { signal }  from '@preact/signals';
import { html }    from 'htm/preact'; window.html = html;
import { Icon }    from 'tools';
import hljs        from 'highlight.js';
import json        from 'highlight.js/languages/json';
import { CodeInputPane, CodeOutputPane } from 'tools';
import { signalWithStorage } from 'preact-x';

hljs.registerLanguage('json', json);

let input  = signalWithStorage('', 'json-minifyer:input');
let output = signal('');
let status = signal('idle');
let errMsg = signal('');
let stats  = signal(null);

function doMinify() {
  let src = input.value.trim();
  if (!src) return;
  errMsg.value = '';
  try {
    let out    = JSON.stringify(JSON.parse(src));
    output.value = out;
    stats.value  = { before: src.length, after: out.length, ratio: Math.round((1 - out.length / src.length) * 100) };
    status.value = 'done';
  } catch(e) {
    errMsg.value = e.message;
    status.value = 'error';
    output.value = '';
    stats.value  = null;
  }
}

let clear = () => { input.value = ''; output.value = ''; stats.value = null; status.value = 'idle'; };

function App() {
  return html`
    <div id="app-body">
      <div class="panes">
        <${CodeInputPane}  lang='json' sig=${input} placeholder="Paste JSON here…" />
        <${CodeOutputPane} lang='json' sig=${output} status=${status} errMsg=${errMsg} stats=${stats} />
      </div>
      <div class="actions">
        <button class="btn primary" onClick=${doMinify} disabled=${!input.value}>
          <${Icon} name="mdi:lightning-bolt" /> Minify
        </button>
        <button class="btn secondary" onClick=${clear} disabled=${!input.value}>
          <${Icon} name="mdi:close" /> Clear
        </button>
      </div>
    </div>`;
}

render(html`<${App} />`, document.getElementById('app'));