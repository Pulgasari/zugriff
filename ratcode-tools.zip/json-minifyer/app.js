// json-minifyer/app.js

import { render } from 'preact';
import { html }   from 'htm/preact'; window.html = html;
import { CodeTransformerApp } from 'tools';

let App = CodeTransformerApp ({
  appID       : 'json-minifyer',
  lang        : 'json',
  langExt     : 'json',
  actionLabel : 'Minify',
  placeholder : 'Paste JSON here…',
  execute     : src => JSON.stringify(JSON.parse(src)),
});

render(html`<${App} />`, document.getElementById('app'));