// csv-converter/app.js

import { render } from 'preact';
import { html } from 'htm/preact'; window.html = html;
import { CodeConverterApp } from 'tool';
import { convert } from '../.components/data-converters.js';

let FORMATS = [
  { id: 'json', label: 'JSON', lang: 'json',        ext: 'json' },
  { id: 'yaml', label: 'YAML', lang: 'yaml',        ext: 'yaml' },
  { id: 'toml', label: 'TOML', lang: 'toml',        ext: 'toml' },
  { id: 'js',   label: 'JS',   lang: 'javascript',  ext: 'js'   },
];

let App = CodeConverterApp ({
  appID       : 'csv-converter',
  inputLang   : 'plaintext',
  inputExt    : 'csv',
  placeholder : 'Paste CSV here…',
  actionLabel : 'Convert',
  formats     : FORMATS,
  execute     : (src, fmt) => convert(src, 'csv', fmt),
});

render(html`<${App} />`, document.getElementById('app'));