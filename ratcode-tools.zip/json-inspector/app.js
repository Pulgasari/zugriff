// json-inspector/app.js

import { render } from 'preact';
import { html } from 'htm/preact'; window.html = html;
import { DataInspectorApp } from 'tools';
import hljs from 'highlight.js';
import json from 'highlight.js/languages/json';

hljs.registerLanguage('json', json);

let App = DataInspectorApp({
  appID       : 'json-inspector',
  lang        : 'json',
  icon        : 'mdi:code-json',
  placeholder : 'Paste JSON here …',
  parse       : src  => JSON.parse(src),
  format      : data => JSON.stringify(data, null, 2),
  emptyIcon   : 'mdi:code-json',
  emptyLabel  : 'Paste JSON and click Inspect',
});

render(html`<${App} />`, document.getElementById('app'));