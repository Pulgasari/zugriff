// json-inspector/app.js

import { render } from 'preact';
import { signal } from '@preact/signals';
import { useState } from 'preact/hooks';
import { html } from 'htm/preact'; window.html = html;
import { CodeInputPane, Icon } from 'tools';
import { signalWithStorage } from 'preact-x';
import hljs from 'highlight.js';
import json from 'highlight.js/languages/json';

hljs.registerLanguage('json', json);

// ── state ─────────────────────────────────────────────────────────────────────
let input   = signalWithStorage('');
let parsed  = signal(null);
let errMsg  = signal('');
let search  = signal('');

// ── parse ─────────────────────────────────────────────────────────────────────
function doParse() {
  let src = input.value.trim();
  if (!src) { parsed.value = null; errMsg.value = ''; return; }
  try {
    parsed.value = JSON.parse(src);
    errMsg.value = '';
  } catch(e) {
    parsed.value = null;
    errMsg.value = e.message;
  }
}

// ── path copy ─────────────────────────────────────────────────────────────────
let copyVal  = val  => navigator.clipboard.writeText( typeof val === 'string' ? val : JSON.stringify(val, null, 2) );
let copyPath = path => navigator.clipboard.writeText(path);

// ── type helpers ──────────────────────────────────────────────────────────────
let typeOf = v => v === null ? 'null' : Array.isArray(v) ? 'array' : typeof v;
/*
let typeOf = v => {
  if (v === null)       return 'null';
  if (Array.isArray(v)) return 'array';
  return typeof v;
};
*/
let typeIcon = type => ({
  object  : 'mdi:code-braces',
  array   : 'mdi:code-brackets',
  string  : 'mdi:format-quote-close',
  number  : 'mdi:numeric',
  boolean : 'mdi:toggle-switch-outline',
  null    : 'mdi:null',
})[type] ?? 'mdi:help';

let typeColor = type => ({
  string  : 'var(--c-string)',
  number  : 'var(--c-number)',
  boolean : 'var(--c-bool)',
  null    : 'var(--c-null)',
})[type];

function matchesSearch(node, q) {
  if (!q) return true;
  let str = JSON.stringify(node).toLowerCase();
  return str.includes(q.toLowerCase());
}

// ── Node ─────────────────────────────────────────────────────────────────────
function Node({ keyName, value, path, depth = 0, defaultOpen = true }) {
  let type     = typeOf(value);
  let isComplex = type === 'object' || type === 'array';
  let [open, setOpen] = useState(defaultOpen && depth < 3);
  let q = search.value;

  if (isComplex) {
    let entries = type === 'array'
      ? value.map((v, i) => [i, v])
      : Object.entries(value);
    let count   = entries.length;
    let bracket = type === 'array' ? ['[', ']'] : ['{', '}'];

    // filter entries by search
    let visible = q
      ? entries.filter(([k, v]) => {
          let keyMatch = String(k).toLowerCase().includes(q.toLowerCase());
          return keyMatch || matchesSearch(v, q);
        })
      : entries;

    return html`
      <div class=${'node depth-' + depth}>
        <div class="node-row" onClick=${() => setOpen(o => !o)}>
          <${Icon} name=${open ? 'mdi:chevron-down' : 'mdi:chevron-right'} class="toggle-icon" />
          ${keyName !== undefined && html`<span class="node-key">${keyName}</span><span class="colon">:</span>`}
          <${Icon} name=${typeIcon(type)} class="type-icon" />
          <span class="bracket">${bracket[0]}</span>
          ${!open && html`<span class="preview">${count} ${count === 1 ? 'item' : 'items'}</span>`}
          ${!open && html`<span class="bracket">${bracket[1]}</span>`}
          <div class="node-actions" onClick=${e => e.stopPropagation()}>
            <button class="act-btn" title="Copy path" onClick=${() => copyPath(path)}>
              <${Icon} name="mdi:vector-link" />
            </button>
            <button class="act-btn" title="Copy value" onClick=${() => copyVal(value)}>
              <${Icon} name="mdi:content-copy" />
            </button>
          </div>
        </div>
        ${open && html`
          <div class="node-children">
            ${visible.map(([k, v]) => html`
              <${Node}
                key=${k}
                keyName=${k}
                value=${v}
                path=${type === 'array' ? path + '[' + k + ']' : path + '.' + k}
                depth=${depth + 1}
              />`)}
            ${q && visible.length < entries.length && html`
              <div class="filtered-hint">${entries.length - visible.length} hidden by filter</div>`}
          </div>
          <div class="node-row closing">
            <span class="bracket">${bracket[1]}</span>
          </div>`}
      </div>`;
  }

  // primitive
  let strVal = value === null ? 'null'
    : type === 'string'  ? '"' + value + '"'
    : String(value);

  let highlight = q && strVal.toLowerCase().includes(q.toLowerCase());

  return html`
    <div class=${'node depth-' + depth + (highlight ? ' highlighted' : '')}>
      <div class="node-row leaf">
        <span class="leaf-indent" />
        ${keyName !== undefined && html`<span class="node-key">${keyName}</span><span class="colon">:</span>`}
        <${Icon} name=${typeIcon(type)} class="type-icon" style=${{ color: typeColor(type) }} />
        <span class="prim-val" style=${{ color: typeColor(type) }}>${strVal}</span>
        <div class="node-actions">
          <button class="act-btn" title="Copy path" onClick=${() => copyPath(path)}>
            <${Icon} name="mdi:vector-link" />
          </button>
          <button class="act-btn" title="Copy value" onClick=${() => copyVal(value)}>
            <${Icon} name="mdi:content-copy" />
          </button>
        </div>
      </div>
    </div>`;
}

// ── Stats ─────────────────────────────────────────────────────────────────────
function collectStats(val, stats = { keys: 0, strings: 0, numbers: 0, booleans: 0, nulls: 0, depth: 0 }, depth = 0) {
  stats.depth = Math.max(stats.depth, depth);
  let type = typeOf(val);
  if (type === 'object' || type === 'array') {
    let entries = type === 'array' ? val : Object.values(val);
    if (type === 'object') stats.keys += Object.keys(val).length;
    (type === 'array' ? val : Object.values(val)).forEach(v => collectStats(v, stats, depth + 1));
  } else {
    if (type === 'string')  stats.strings++;
    if (type === 'number')  stats.numbers++;
    if (type === 'boolean') stats.booleans++;
    if (type === 'null')    stats.nulls++;
  }
  return stats;
}

function Stats({ value }) {
  let s = collectStats(value);
  let items = [
    [ 'mdi:code-braces',          s.keys,     'keys'      ],
    [ 'mdi:format-quote-close',   s.strings,  'strings'   ],
    [ 'mdi:numeric',              s.numbers,  'numbers'   ],
    [ 'mdi:toggle-switch-outline',s.booleans, 'booleans'  ],
    [ 'mdi:null',                 s.nulls,    'nulls'     ],
    [ 'mdi:arrow-collapse-down',  s.depth,    'max depth' ],
  ];
  return html`
    <div class="stats-bar">
      ${items.map(([icon, val, label]) => val > 0 && html`
        <span class="stat">
          <${Icon} name=${icon} /> ${val} ${label}
        </span>`)}
    </div>`;
}

// ── App ───────────────────────────────────────────────────────────────────────
function App() {
  let data = parsed.value;
  let err  = errMsg.value;

  return html`
    <div id="app-body">
      <div class="layout">
        
        <div class="input-col">
          <${CodeInputPane} sig=${input} lang="json" placeholder="Paste JSON here…" />
          <div class="input-actions">
            <button class="btn primary" onClick=${doParse} disabled=${!input.value}>
              <${Icon} name="mdi:magnify" /> Inspect
            </button>
            ${data && html`
              <button class="btn secondary" onClick=${() => {
                input.value  = JSON.stringify(data, null, 2);
                doParse();
              }}>
                <${Icon} name="mdi:auto-fix" /> Format
              </button>`}
            ${input.value && html`
              <button class="btn secondary" onClick=${() => { input.value = ''; parsed.value = null; errMsg.value = ''; }}>
                <${Icon} name="mdi:close" /> Clear
              </button>`}
          </div>
          ${err && html`
            <div class="err-block">
              <${Icon} name="mdi:alert-circle-outline" /> ${err}
            </div>`}
        </div>
        
        <div class="tree-col">
          ${data !== null && data !== undefined ? html`
            <${Stats} value=${data} />
            <div class="search-row">
              <${Icon} name="mdi:magnify" class="search-icon" />
              <input class="search-input" type="text" placeholder="Filter keys & values…"
                value=${search.value} onInput=${e => search.value = e.target.value} />
              ${search.value && html`
                <button class="act-btn" onClick=${() => search.value = ''}>
                  <${Icon} name="mdi:close" />
                </button>`}
            </div>
            <div class="tree">
              <${Node} value=${data} path="$" depth=${0} />
            </div>
          ` : html`
            <div class="tree-empty">
              <${Icon} name="mdi:code-json" size="32" />
              <span>Paste JSON and click Inspect</span>
            </div>`}
        </div>
        
      </div>
    </div>`;
}

render(html`<${App} />`, document.getElementById('app'));