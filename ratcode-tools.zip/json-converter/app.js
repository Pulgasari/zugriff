// json-converter/app.js

import { render } from 'preact';
import { html } from 'htm/preact'; window.html = html;
import { CodeConverterApp } from 'tools';
import { convert } from '../.components/data-converters.js';

let FORMATS = [
  { id: 'csv',  label: 'CSV',  lang: 'plaintext',   ext: 'csv'  },
  { id: 'yaml', label: 'YAML', lang: 'yaml',        ext: 'yaml' },
  { id: 'toml', label: 'TOML', lang: 'toml',        ext: 'toml' },
  { id: 'js',   label: 'JS',   lang: 'javascript',  ext: 'js'   },
];

let App = CodeConverterApp ({
  appID       : 'json-converter',
  inputLang   : 'json',
  inputExt    : 'json',
  placeholder : 'Paste JSON here…',
  actionLabel : 'Convert',
  formats     : FORMATS,
  execute     : (src, fmt) => convert(src, 'json', fmt),
});

render(html`<${App} />`, document.getElementById('app'));