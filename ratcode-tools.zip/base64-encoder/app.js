import { render } from 'preact';
import { html } from 'htm/preact'; window.html = html;
import { CodeTransformerApp } from 'tools';

let App = CodeTransformerApp({
  appID       : 'b64enc',
  lang        : 'plaintext',
  ext         : 'txt',
  actionLabel : 'Encode',
  placeholder : 'Paste text here …',
  execute     : src => btoa(unescape(encodeURIComponent(src))),
});

render(html`<${App} />`, document.getElementById('app'));