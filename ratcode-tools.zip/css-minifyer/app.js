// css-minifyer/app.js

import { render } from 'preact';
import { html }   from 'htm/preact'; window.html = html;
import { minify } from 'csso';
import { CodeTransformerApp } from 'tools';

// https://github.com/css/csso
// restructure: false
// forceMediaMerge

let App = CodeTransformerApp({
  appID       : 'css-minifyer',
  lang        : 'css',
  langExt     : 'css',
  actionLabel : 'Minify',
  placeholder : 'Paste CSS here …',
  execute     : src => minify(src).css,
});

render(html`<${App} />`, document.getElementById('app'));