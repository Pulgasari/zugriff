import { render }        from 'preact';
import { signal }        from '@preact/signals';
import { html }          from 'htm/preact'; window.html = html;
import { useEffect, useRef } from 'preact/hooks';
import { CodeInputPane, CodeOutputPane, Icon, Toggle } from 'tools';
import { minify } from 'csso';
import { signalWithStorage } from 'preact-x';
import { debounce } from 'ratlib';

// ── state ────────────────────────────────────────────────────────────
let live   = signalWithStorage(false, 'css-minifyer:live');
let input  = signalWithStorage('', 'css-minifyer:input');
let output = signal('');
let status = signal('idle');
let errMsg = signal('');
let stats  = signal(null);

// ── options ───────────────────────────────────────────────────────────────────
let opts = {
  restructure: true,   // merge selectors/properties where safe
};

// ── logic ─────────────────────────────────────────────────────────────────────
async function doMinify() {
  let src = input.value.trim();
  if (!src) {
    output.value = '';
    stats.value  = null;
    status.value = 'idle';
    errMsg.value = '';
    return;
  }
  status.value = 'minifying';
  errMsg.value = '';
  try {
    let result = minify(src, opts);
    let out    = result.css ?? '';
    output.value = out;
    stats.value  = {
      before: src.length,
      after:  out.length,
      ratio:  Math.round((1 - out.length / src.length) * 100),
    };
    status.value = 'done';
  } catch(e) {
    errMsg.value = e.message;
    status.value = 'error';
    output.value = '';
    stats.value  = null;
  }
}

// live mode
let debouncedMinify = debounce(doMinify, 1000);
effect(() => live.value && (input.value, debouncedMinify()) );

// initial restore
if (input.value) doMinify();

// ── App ───────────────────────────────────────────────────────────────────────
function App() {
  let busy   = status.value === 'minifying';
  
  return html`
    <div id="app-body">
      
      <div class="panes">
        <${CodeInputPane}  sig=${input}  lang="css" filename="input.css" placeholder="Paste CSS here …" />
        <${CodeOutputPane} sig=${output} lang="css" filename="output.min.css" status=${status} errorMessage=${errMsg} stats=${stats} />
      </div>
      
      <div class="actions">
        ${!live.value && html`
          <button class="btn primary" onClick=${doMinify} disabled=${busy || !input.value}>
            <${Icon} name=${busy ? 'mdi:loading' : 'mdi:lightning-bolt'} class=${busy ? 'spin' : ''} />
            ${busy ? 'Minifying…' : 'Minify'}
          </button>
        `}
        <${Toggle} value=${live.value} onChange=${v => live.value = v} label="Live-Mode" />
      </div>
      
    </div>`;
}

render(html`<${App} />`, document.getElementById('app'));