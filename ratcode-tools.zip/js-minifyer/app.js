// js-minifyer/app.js

import { render } from 'preact';
import { html }   from 'htm/preact'; window.html = html;
import { minify } from 'terser';
import { CodeTransformerApp } from 'tools';

let App = CodeTransformerApp ({
  appID       : 'js-minifyer',
  lang        : 'javascript',
  langExt     : 'js',
  actionLabel : 'Minify',
  placeholder : 'Paste JavaScript here…',
  execute     : async src => (await minify(src, { compress: true, mangle: true })).code,
});

render(html`<${App} />`, document.getElementById('app'));