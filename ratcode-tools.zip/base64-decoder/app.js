import { render } from 'preact';
import { html } from 'htm/preact'; window.html = html;
import { CodeTransformerApp } from 'tools';

let App = CodeTransformerApp({
  appID       : 'b64dec',
  lang        : 'plaintext',
  ext         : 'txt',
  actionLabel : 'Decode',
  placeholder : 'Paste Base64 here …',
  execute     : src => decodeURIComponent(escape(atob(src.trim()))),
});

render(html`<${App} />`, document.getElementById('app'));