// toml-converter/app.js

import { render } from 'preact';
import { html } from 'htm/preact'; window.html = html;
import { CodeConverterApp } from 'tools';
import { convert } from '../.components/data-converters.js';

let FORMATS = [
  { id: 'csv',  label: 'CSV',  lang: 'plaintext',   ext: 'csv'  },
  { id: 'json', label: 'JSON', lang: 'json',        ext: 'json' },
  { id: 'yaml', label: 'YAML', lang: 'yaml',        ext: 'yaml' },
  { id: 'js',   label: 'JS',   lang: 'javascript',  ext: 'js'   },
];

let App = CodeConverterApp ({
  appID       : 'toml-converter',
  inputLang   : 'toml',
  inputExt    : 'toml',
  placeholder : 'Paste TOML here…',
  actionLabel : 'Convert',
  formats     : FORMATS,
  execute     : (src, fmt) => convert(src, 'toml', fmt),
});

render(html`<${App} />`, document.getElementById('app'));