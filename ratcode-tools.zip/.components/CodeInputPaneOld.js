// .components/CodeInputValue.js

import { Icon } from 'tools';

export default function CodeInputPane ({ sig, placeholder = 'Paste code here…' }) {
  return html`
    <div class="pane">

      <div class="pane-header">
        <span>Input</span>
        ${sig.value && html`
          <button class="ghost-btn" onClick=${() => sig.value = ''}>
            <${Icon} name="mdi:close" /> Clear
          </button>`}
      </div>

      <textarea
        class="code-input"
        placeholder=${placeholder}
        spellcheck="false"
        value=${sig.value}
        onInput=${event => sig.value = event.target.value}
      />

      <div class="pane-footer">
        ${sig.value && html`<span class="char-count">${sig.value.length} chars</span>`}
      </div>

    </div>
  `;
}