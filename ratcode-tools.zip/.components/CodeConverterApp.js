// components/CodeConverterApp.js

import CodeInputPane  from './CodeInputPane.js';
import CodeOutputPane from './CodeOutputPane.js';
import Icon           from './Icon.js';
import Toggle         from './Toggle.js';

import { signal, effect }    from '@preact/signals';
import { signalWithStorage } from 'preact-x';
import { debounce }          from 'ratlib';

export default function CodeConverterApp ({
  appID          = 'app',
  debounceTime   = 1000,
  // lang/ext fallbacks — used when input/output not specified separately
  lang           = 'javascript',
  langExt        = 'js',
  // per-pane overrides
  inputLang      = null,
  inputExt       = null,
  outputLang     = null,
  outputExt      = null,
  placeholder    = 'Paste code here…',
  inputFilename  = null,
  outputFilename = null,
  actionLabel    = 'Run',
  // optional format switcher: [{ id, label, lang, ext }]
  formats        = null,
  execute,  // (src: string, format?: string) => string | Promise<string>
  // for InputPane
  couldURL       = true, 
  couldUpload    = true,
  uploadAccept   = 'text/*',
}) {
  let iLang = inputLang  ?? lang;
  let iExt  = inputExt   ?? langExt;
  let oLang = outputLang ?? lang;
  let oExt  = outputExt  ?? langExt;

  let live   = signalWithStorage(false, appID + ':live');
  let input  = signalWithStorage('',    appID + ':input');
  let output = signal('');
  let status = signal('idle');
  let errMsg = signal('');
  let stats  = signal(null);

  // active output format (when formats[] provided)
  let fmt = formats
    ? signalWithStorage(formats[0].id, appID + ':fmt')
    : null;

  let activeFmt  = () => fmt ? formats.find(f => f.id === fmt.value) : null;
  let activeOLang = () => activeFmt()?.lang ?? oLang;
  let activeOExt  = () => activeFmt()?.ext  ?? oExt;

  let filenameInput  = inputFilename  ?? 'input.'  + iExt;
  let filenameOutput = () => outputFilename ?? 'output.' + activeOExt();

  async function doExecute() {
    let src = input.value.trim();
    if (!src) {
      output.value = '';
      stats.value  = null;
      status.value = 'idle';
      errMsg.value = '';
      return;
    }
    status.value = 'running';
    errMsg.value = '';
    try {
      let out = await execute(src, fmt?.value);
      output.value = out;
      stats.value  = { before: src.length, after: out.length, ratio: Math.round((1 - out.length / src.length) * 100) };
      status.value = 'done';
    } catch(e) {
      errMsg.value = e.message;
      status.value = 'error';
      output.value = '';
      stats.value  = null;
    }
  }

  let debouncedExecute = debounce(doExecute, debounceTime);
  effect(() => live.value && (input.value, debouncedExecute()));
  // re-run when format changes
  if (fmt) effect(() => { fmt.value; if (input.value) doExecute(); });
  if (input.value) doExecute();

  function App() {
    let busy = status.value === 'running';

    return html`
      <div id="app-body">

        <div class="panes">
          <${CodeInputPane}
            sig=${input}
            lang=${iLang}
            filename=${filenameInput}
            placeholder=${placeholder}
          />
          <${CodeOutputPane}
            sig=${output}
            lang=${activeOLang()}
            filename=${filenameOutput()}
            status=${status}
            errorMessage=${errMsg}
            stats=${stats}
          />
        </div>

        <div id="app-actions">
          ${formats && html`
            <div class="format-picker">
              ${formats.map(f => html`
                <button
                  class=${'chip' + (fmt.value === f.id ? ' active' : '')}
                  onClick=${() => fmt.value = f.id}>
                  ${f.label}
                </button>`)}
            </div>`}
          ${!live.value && html`
            <button class="btn primary" onClick=${doExecute} disabled=${busy || !input.value}>
              <${Icon} name=${busy ? 'mdi:loading' : 'mdi:lightning-bolt'} class=${busy ? 'spin' : ''} />
              ${busy ? 'Running…' : actionLabel}
            </button>`}
          <${Toggle} value=${live.value} onChange=${v => live.value = v} label="Live-Mode" />
        </div>

      </div>`;
  }

  return App;
}