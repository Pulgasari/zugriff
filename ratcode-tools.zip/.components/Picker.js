// .components/Picker.js

import Icon from './Icon.js';

const isObject = v => typeof v === 'object' && v !== null;

export default function Picker ({ options, sig }) {
  return html`
    <div class='picker'>
      ${options.map( opt => {
        let icon, label, title, value;
      
        if (isObject(opt)) {
          value = opt.value;
          label = opt.label ?? ( !opt.icon ? opt.value : '');
          icon  = isObject(opt) ? (opt.icon ?? null) : null;
          title = opt.title ?? opt.label ?? opt.value ?? null;
        } else {
          value = opt;
          label = opt;
          title = opt;
        }

        return html`
          <button 
            class=${sig.value === value && 'active'} 
            onClick=${() => sig.value = value}
            title=${title}
            >
            ${icon && html`<${Icon} name=${icon} />`}
            ${label}
          </button>`;
      })}
    </div>`;
}

/*
export default function Picker ({ options, sig }) {
  return html`
    <div class='picker'>
      ${options.map( opt => html`
        <button class=${sig.value === opt && 'active'} onClick=${() => sig.value = opt}>
          ${opt}
        </button>`
      )}
    </div>`;
}
*/