// .components/GhostButton.js

import Icon from './Icon.js';

export default function GhostButton ({ children, icon, label, text, onClick }) {
  return html`
    <button class='btn ghost ghost-btn' onClick=${onClick}>
      ${icon && html`<${Icon} name=${icon} />`}
      ${children || label || text}
    </button>
  `;
}