// .components/CodeOutputPane.js

import GhostButton from './GhostButton.js';
import Icon        from './Icon.js';
import { useEffect, useRef } from 'preact/hooks';
import { hljs, ensureLang } from './hljs.js';
//import hljs from 'highlight.js';

function Highlighted({ code, lang }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current) return;
    ensureLang(lang).then(() => {
      ref.current.removeAttribute('data-highlighted');
      ref.current.textContent = code;
      hljs.highlightElement(ref.current);
    });
  }, [code, lang]);
  if (!code) return null;
  return html`<pre class="output-pre"><code class=${'language-' + lang} ref=${ref}></code></pre>`;
}

export default function CodeOutputPane ({ sig, status, errorMessage, filename, stats, lang = 'javascript', title = 'Output' }) {
  let hasOut = !!sig.value;
  let s      = stats?.value;
  let copy     = () => navigator.clipboard.writeText(sig.value);
  let select   = () => { let r = document.createRange(); r.selectNodeContents(ref.current); let s = window.getSelection(); s.removeAllRanges(); s.addRange(r); };
  let download = () => {
    if (!filename) return;
    let a = Object.assign(document.createElement('a'), {
      href:     URL.createObjectURL(new Blob([sig.value], { type: 'text/plain' })),
      download: filename,
    });
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return html`
    <div class="pane">
      
      <div class="pane-header">
        <span class='pane-title'>${title}</span>
        <div class='pane-actions'>
          ${hasOut && html`
            <${GhostButton} icon='mdi:content-copy' text='Copy'     onClick=${copy}     />
            ${filename && html`<${GhostButton} icon='mdi:download'     text='Download' onClick=${download} />`}
            <${GhostButton} icon='mdi:select-all'   text='Select'   onClick=${select}   />
          `}
        </div>
      </div>
      
      <div class=${'output-wrap' + (!hasOut ? ' empty' : '')}>
        ${!hasOut && status.value !== 'error' && html`
          <span class="placeholder">Minified output appears here…</span>
        `}
        ${status.value === 'error' && html`
          <div class="err-block">
            <${Icon} name="mdi:alert-circle-outline" /><pre>${errMsg.value}</pre>
          </div>
        `}
        ${hasOut && html`<${Highlighted} code=${sig.value} lang=${lang} />`}
      </div>
      
      <div class="pane-footer">
        ${hasOut && html`
          <span class="stats">
            ${s && html`<span class="stat-badge">${s.ratio}% smaller</span> ${s.after} chars`}
          </span>
        `}
      </div>
      
    </div>
  `;
}