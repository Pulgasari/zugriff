import hljs from 'highlight.js';

const registered = new Set();

export async function ensureLang (lang) {
  if (registered.has(lang)) return;
  const mod = await import('highlight.js/languages/' + lang);
  hljs.registerLanguage(lang, mod.default);
  registered.add(lang);
}

export { hljs };