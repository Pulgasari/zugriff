// components/Icon.js

//import icons from '../.data/icons.json' with { type: 'json' };

let icons = JSON.parse(`{
  "add": "material-symbols:add",
  "remove": "material-symbols:remove",
  "arrow-down": "material-symbols:arrow-downward",
  "arrow-left": "material-symbols:arrow-back",
  "arrow-right": "material-symbols:arrow-forward",
  "arrow-up": "material-symbols:arrow-upward",
  "close": "fa:close",
  "commands": "material-symbols:keyboard-command-key",
  "copy": "bx:copy",
  "copy-all": "material-symbols:copy-all",
  "copy-file": "material-symbols:file-copy",
  "cut": "material-symbols:cut",
  "deselect": "material-symbols:deselect",
  "download": "mdi:download",
  "download-multiple": "mdi:download-multiple-outline",
  "enter": "material-symbols:keyboard-return",
  "join-lines": "material-symbols:join-outline",
  "paste": "material-symbols:content-paste",
  "previewer": "material-symbols:preview",
  "redo": "bx:redo",
  "refresh": "material-symbols:refresh",
  "save": "material-symbols:file-save",
  "search": "material-symbols:search",
  "select-all": "material-symbols:select-all",
  "settings": "material-symbols:settings",
  "space": "material-symbols:space-bar",
  "tab": "bx:arrow-to-right",
  "tab-rtl": "bx:arrow-to-left",
  "toggle-off": "material-symbols:toggle-off",
  "toggle-on": "material-symbols:toggle-on",
  "toolbar": "material-symbols:widgets",
  "undo": "bx:undo",
  "lineheight": "material-symbols:format-line-spacing",
  "fontsize": "material-symbols:format-size",
  "workspaces": "grommet-icons:projects",
  "file": "material-symbols:description",
  "folder": "material-symbols:folder",
  "folder-open": "material-symbols:folder-open",
  "loading": "svg-spinners:bars-scale-middle"
}`);

export default function Icon ({ name, size, color = 'currentColor', onClick, title }) {
  let icon  = name.includes(':') ? name : (icons[name] || 'material-symbols:help');
  let style = { color };
  if (size) style.fontSize = `${size}px`;
  return html`<iconify-icon className='icon' icon=${icon} style=${style} title=${title} onClick=${onClick}></iconify-icon>`;
}