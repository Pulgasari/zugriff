// .components/Button.js

import Icon from './Icon.js';

export default function Button ({ children, className, icon, onClick, label, text }) {
  return html`
    <button class=${className} onClick=${onClick}>
      ${icon && html`<${Icon} name=${icon} />`}
      ${children || label || text}
    </button>
  `;
}