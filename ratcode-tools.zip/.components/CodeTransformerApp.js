// components/CodeTransformerApp.js

import CodeInputPane  from './CodeInputPane.js';
import CodeOutputPane from './CodeOutputPane.js';
import Icon           from './Icon.js';
import Toggle         from './Toggle.js';

import { signal, effect }    from '@preact/signals';
import { signalWithStorage } from 'preact-x';
import { debounce }          from 'ratlib';

export default function CodeTransformerApp ({
  appID          = 'app',
  debounceTime   = 1000,
  lang           = 'javascript',
  langExt        = 'js',
  placeholder    = 'Paste code here …',
  inputFilename  = null,
  outputFilename = null,
  actionLabel    = 'Run',
  execute, // (src: string) => string | Promise<string>
  // for InputPane
  couldURL       = true, 
  couldUpload    = true,
  uploadAccept   = 'text/*',
}) {
  // ── state ────────────────────────────────────────────────────────
  let live   = signalWithStorage(false, appID + ':live');
  let input  = signalWithStorage('',    appID + ':input');
  let output = signal('');
  let status = signal('idle');
  let errMsg = signal('');
  let stats  = signal(null);

  let filenameInput  = inputFilename  ?? 'input.'  + langExt;
  let filenameOutput = outputFilename ?? 'output.' + langExt;

  // ── logic ────────────────────────────────────────────────────────
  async function doExecute() {
    let src = input.value.trim();
    if (!src) {
      output.value = '';
      stats.value  = null;
      status.value = 'idle';
      errMsg.value = '';
      return;
    }
    status.value = 'running';
    errMsg.value = '';
    try {
      let out = await execute(src); // ← caller return string
      output.value = out;
      stats.value  = { before: src.length, after: out.length, ratio: Math.round((1 - out.length / src.length) * 100) };
      status.value = 'done';
    } catch(e) {
      errMsg.value = e.message;
      status.value = 'error';
      output.value = '';
      stats.value  = null;
    }
  }

  let debouncedExecute = debounce(doExecute, debounceTime);
  effect(() => live.value && (input.value, debouncedExecute()));
  if (input.value) doExecute();

  // ── component ────────────────────────────────────────────────────
  function App() {
    let busy = status.value === 'running';
    
    return html`
      <div id="app-body">
        
        <div class="panes">
          <${CodeInputPane}  sig=${input}  lang=${lang} filename=${filenameInput}  placeholder=${placeholder} couldURL=${couldURL} couldUpload=${couldUpload} uploadAccept=${uploadAccept} />
          <${CodeOutputPane} sig=${output} lang=${lang} filename=${filenameOutput} status=${status} errorMessage=${errMsg} stats=${stats} />
        </div>
        
        <div id='app-actions'>
          ${!live.value && html`
            <button class="btn primary" onClick=${doExecute} disabled=${busy || !input.value}>
              <${Icon} name=${busy ? 'mdi:loading' : 'mdi:lightning-bolt'} class=${busy ? 'spin' : ''} />
              ${busy ? 'Running…' : actionLabel}
            </button>`}
          <${Toggle} value=${live.value} onChange=${v => live.value = v} label="Live-Mode" />
        </div>
        
      </div>`;
  }

  return App;
}