// .components/Prompt.js

import { signal }   from '@preact/signals';
import GhostButton  from './GhostButton.js';
import Icon         from './Icon.js';

// ── shared prompt state (singleton overlay) ───────────────────────────────────
let promptState = signal(null);
// { title, placeholder, value, type, onConfirm, onCancel }

export function openPrompt({ title, placeholder = '', type = 'text', onConfirm, onCancel }) {
  promptState.value = { title, placeholder, type, value: '', onConfirm, onCancel };
}

export function Prompt() {
  let state = promptState.value;
  if (!state) return null;

  let confirm = () => {
    let val = state.value;
    promptState.value = null;
    state.onConfirm?.(val);
  };
  let cancel = () => {
    promptState.value = null;
    state.onCancel?.();
  };
  let onKeyDown = e => {
    if (e.key === 'Enter')  confirm();
    if (e.key === 'Escape') cancel();
  };

  return html`
    <div class="prompt-overlay" onClick=${cancel}>
      <div class="prompt-dialog" onClick=${e => e.stopPropagation()}>
        <div class="prompt-header">
          <span class="prompt-title">${state.title}</span>
          <${GhostButton} icon="mdi:close" onClick=${cancel} />
        </div>
        <input
          class="prompt-input"
          type=${state.type}
          placeholder=${state.placeholder}
          value=${state.value}
          autoFocus
          onInput=${e => { promptState.value = { ...state, value: e.target.value }; }}
          onKeyDown=${onKeyDown}
        />
        <div class="prompt-actions">
          <button class="btn secondary" onClick=${cancel}>Cancel</button>
          <button class="btn primary"   onClick=${confirm} disabled=${!state.value}>Confirm</button>
        </div>
      </div>
    </div>`;
}