// .components/Waveform.js

import { useRef, useEffect } from 'preact/hooks';

export default function Waveform({ peaks, start, end, duration, playPos }) {
  let canvasRef = useRef(null);

  useEffect(() => {
    let canvas = canvasRef.current;
    if (!canvas || !peaks) return;
    
    let W = canvas.width  = canvas.offsetWidth;
    let H = canvas.height = canvas.offsetHeight;
    if (!W || !H) return;

    let ctx    = canvas.getContext('2d');
    let style  = getComputedStyle(document.documentElement);
    // Fallbacks provided just in case CSS vars aren't loaded yet
    let accent = style.getPropertyValue('--accent').trim() || '#3498db';
    let fg     = style.getPropertyValue('--fg').trim()     || '#ffffff';
    let sx     = (start / duration) * W;
    let ex     = (end   / duration) * W;
    let barW   = Math.max(1.5, W / peaks.length - 0.5);

    ctx.clearRect(0, 0, W, H);

    // Draw peaks
    for (let i = 0; i < peaks.length; i++) {
      let x = (i / peaks.length) * W;
      let inside = x >= sx && x <= ex;
      ctx.fillStyle   = inside ? accent : fg;
      ctx.globalAlpha = inside ? 0.85 : 0.15; // Normalized alpha between both apps
      ctx.fillRect(x, (H - peaks[i] * H * 0.85) / 2, barW, peaks[i] * H * 0.85);
    }
    ctx.globalAlpha = 1;

    // Draw playhead
    if (playPos > 0) {
      ctx.fillStyle   = fg; 
      ctx.globalAlpha = 0.85;
      ctx.fillRect(playPos * W - 1, 0, 2, H);
      ctx.globalAlpha = 1;
    }
  }, [peaks, start, end, duration, playPos]); // added dependency array for safety

  if (!peaks) return null;
  return html`<canvas ref=${canvasRef} class="waveform-canvas" />`;
}