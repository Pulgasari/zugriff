// .components/Slider.js

export default function Slider({
  label,
  value,
  min,
  max,
  step = 1,
  style,          // generisch: { '--gradient': '...' } o.ä.
  showButtons,    // optional ±-Buttons
  showNumber,     // optional number input
  onChange,
}) {
  let isFloat  = step < 1;
  let decimals = step < 0.01 ? 4 : 2;
  let disp     = isFloat ? +value.toFixed(decimals) : Math.round(value);
  let width    = (String(max).replace('.', '').length + (isFloat ? 2 : 0)) + 'ch';

  let set   = v => onChange(clamp(v, min, max));
  let nudge = d => set(+(value + d * step).toFixed(decimals));

  return html`
    <div class="slider-row">
      ${label && html`<span class="slider-label">${label}</span>`}
      
      ${showButtons && html`<button class="slider-btn" onClick=${() => nudge(-1)}>−</button>`}
      
      <div class="slider-track" style=${style}>
        <input type='range' ...${{ max, min, step, value }} onInput=${e => onChange(+e.target.value)} />
      </div>
      
      ${showButtons && html`<button class="slider-btn" onClick=${() => nudge(+1)}>+</button>`}
      
      ${showNumber && html`
        <input type="number" class="num-input"
        ...${{ max, min, step }}
          style=${{ width }}
          value=${disp}
          onInput=${e => set(+e.target.value)} />
      `}
    </div>`;
}