// .components/WaveformWithHandles.js

import { useRef } from 'preact/hooks';
import Waveform from './Waveform.js';

// Helper to format handle time
let fmtT = s => Math.floor(s/60) + ':' + (s%60).toFixed(1).padStart(4,'0');

export default function WaveformWithHandles({ peaks, start, end, duration, playPos, onChange }) {
  let wrapRef = useRef(null);

  let xToTime = (clientX) => {
    if (!wrapRef.current) return 0;
    let r = wrapRef.current.getBoundingClientRect();
    return Math.max(0, Math.min(duration, ((clientX - r.left) / r.width) * duration));
  };

  let startDrag = (which) => (e) => {
    e.preventDefault();
    let move = (ev) => {
      let t = xToTime(ev.clientX);
      // Pass the raw requested time back to the parent component
      // The parent is responsible for clamping constraints (min gap, etc)
      onChange(which, t);
    };
    let up = () => { 
      document.removeEventListener('mousemove', move); 
      document.removeEventListener('mouseup', up); 
    };
    document.addEventListener('mousemove', move);
    document.addEventListener('mouseup', up);
  };

  if (!peaks) return null;

  return html`
    <div class="waveform-wrap" ref=${wrapRef}>
    
      <${Waveform} ...${{ duration, end, start, peaks, playPos }} />
      
      <div class="handle handle-s" style=${'left:' + (start / duration * 100).toFixed(3) + '%'}
           onMouseDown=${startDrag('start')}>
        <div class="handle-label">${fmtT(start)}</div>
      </div>
      
      <div class="handle handle-e" style=${'left:' + (end / duration * 100).toFixed(3) + '%'}
           onMouseDown=${startDrag('end')}>
        <div class="handle-label">${fmtT(end)}</div>
      </div>
      
    </div>
  `;
}