// .components/CodeInputPane.js
import GhostButton from './GhostButton.js';
import Icon        from './Icon.js';
import { openPrompt }     from './Prompt.js';
import { useEffect, useRef } from 'preact/hooks';
import { hljs, ensureLang } from './hljs.js';
//import hljs from 'highlight.js';

// ── cursor helpers ────────────────────────────────────────────────────────────
function getCursor (el) {
  let sel = window.getSelection();
  if (!sel.rangeCount) return 0;
  let range = sel.getRangeAt(0).cloneRange();
  range.selectNodeContents(el);
  range.setEnd(sel.getRangeAt(0).endContainer, sel.getRangeAt(0).endOffset);
  return range.toString().length;
}
function setCursor (el, pos) {
  let sel   = window.getSelection();
  let range = document.createRange();
  let chars = 0, found = false;

  (function traverse(node) {
    if (found) return;
    if (node.nodeType === Node.TEXT_NODE) {
      let end = chars + node.length;
      if (end >= pos) {
        range.setStart(node, pos - chars);
        range.collapse(true);
        found = true;
      } else { chars = end; }
    } else {
      for (let child of node.childNodes) traverse(child);
    }
  })(el);

  if (!found) { range.selectNodeContents(el); range.collapse(false); }
  sel.removeAllRanges();
  sel.addRange(range);
}

// ── component ─────────────────────────────────────────────────────────────────
export default function CodeInputPane ({ 
  filename, sig,
  placeholder   = 'Paste code here …', 
  lang          = 'javascript', 
  title         = 'Input',
  couldDownload = false,
  couldSelect   = false,
  couldUpload   = true,
  couldURL      = true,
  uploadAccept  = 'text/*',
}) {
  let ref      = useRef(null);
  let internal = useRef(false);
  let fileRef  = useRef(null);

  useEffect(() => {
    ensureLang(lang).then(() => {
      if (internal.current) { internal.current = false; return; }
      let el = ref.current;
      if (!el) return;
      el.textContent = sig.value;
      if (sig.value) { el.removeAttribute('data-highlighted'); hljs.highlightElement(el); }
    });
  }, [sig.value, lang]);

  let onInput = () => {
    let el  = ref.current;
    let pos = getCursor(el);
    internal.current = true;
    sig.value = el.textContent;
    el.removeAttribute('data-highlighted');
    if (el.textContent) hljs.highlightElement(el);
    setCursor(el, pos);
  };

  let onKeyDown = event => {
    if (event.key !== 'Tab') return;
    event.preventDefault();
    let selection = window.getSelection();
    let range     = selection.getRangeAt(0);
    let tab       = document.createTextNode('  ');
    range.deleteContents();
    range.insertNode(tab);
    range.setStartAfter(tab);
    range.collapse(true);
    selection.removeAllRanges();
    selection.addRange(range);
    onInput();
  };

  let clear    = () => sig.value = '';
  let copy     = () => navigator.clipboard.writeText(sig.value);
  let select   = () => {
    let range = document.createRange();
    range.selectNodeContents(ref.current);
    let selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
  };
  let download = () => {
    if (!filename) return;
    let a = Object.assign(document.createElement('a'), {
      href: URL.createObjectURL(new Blob([sig.value], { type: 'text/plain' })),
      download: filename,
    });
    a.click();
    URL.revokeObjectURL(a.href);
  };

  // ── upload ──────────────────────────────────────────────────────
  let onFileChange = event => {
    let file = event.target.files?.[0];
    if (!file) return;
    file.text().then( text => sig.value = text );
    event.target.value = '';
  };
  let triggerUpload = () => fileRef.current?.click();

  // ── url fetch ───────────────────────────────────────────────────
  let loadFromURL = () => {
    openPrompt({
      title       : 'Load from URL',
      placeholder : 'https://example.com/file.txt',
      type        : 'url',
      onConfirm   : async url => {
        try {
          let res = await fetch(url);
          if (!res.ok) throw new Error(res.statusText);
          sig.value = await res.text();
        } catch(e) {
          alert('Fetch failed: ' + e.message);
        }
      },
    });
  };

  return html`
    <div class="pane">

      <div class="pane-header">
        <span class="pane-title">${title}</span>
        <div class="pane-actions">
          ${couldUpload && html`
            <input type="file" ref=${fileRef} accept=${uploadAccept} style="display:none" onChange=${onFileChange} />
            <${GhostButton} icon="mdi:upload" text="Upload" onClick=${triggerUpload} />
          `}
          ${couldURL && html`<${GhostButton} icon="mdi:web" text="URL" onClick=${loadFromURL} />`}
          ${sig.value && html`
            <${GhostButton} icon="mdi:content-copy" text="Copy"     onClick=${copy}     />
            ${filename    && html`<${GhostButton} icon="mdi:download"   text="Download" onClick=${download} />`}
            ${couldSelect && html`<${GhostButton} icon="mdi:select-all" text="Select"   onClick=${select}   />`}
            <${GhostButton} icon="mdi:close"        text="Clear"    onClick=${clear}    />
          `}
        </div>
      </div>

      <div class="input-wrap">
        <pre class="input-pre"><code
          class=${'language-' + lang}
          contenteditable="true"
          spellcheck="false"
          data-placeholder=${placeholder}
          ref=${ref}
          onInput=${onInput}
          onKeyDown=${onKeyDown}
        /></pre>
      </div>

      <div class="pane-footer">
        ${sig.value && html`<span class="char-count">${sig.value.length} chars</span>`}
      </div>

    </div>
  `;
}