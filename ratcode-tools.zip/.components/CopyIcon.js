// .components/CopyIcon.js
import { signal } from '@preact/signals';
import Icon from './Icon.js';

let copied = signal(null);

function copy (str, time = 1500) {
  navigator.clipboard.writeText(str);
  copied.value = str;
  setTimeout(() => copied.value = null, time);
}

export default function CopyIcon ({ content }) {
  let isCopied = copied.value === content;
  let icon     = isCopied ? 'mdi:check' : 'mdi:content-copy';
  let onClick = () => copy(content);

  return html`<${Icon} name=${icon} onClick=${onClick} title='Copy to Clipboard' />`;
}