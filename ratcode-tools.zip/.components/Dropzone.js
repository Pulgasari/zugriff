// .components/Dropzone.js

import Icon from './Icon.js';



export default function Dropzone ({
  accept   = 'image/*',
  multiple = true,
  icon     = 'mdi:image-plus',
  sig, // the signal
  what     = 'files' 
}) {
  let _id = 0;
  let onDrop      = e => { e.preventDefault(); e.currentTarget.classList.remove('drag-over'); addFiles(e.dataTransfer.files); };
  let onDragOver  = e => { e.preventDefault(); e.currentTarget.classList.add('drag-over'); };
  let onDragLeave = e => e.currentTarget.classList.remove('drag-over');
  let onInput     = e => { addFiles(e.target.files); e.target.value = ''; };
  
  function addFiles (list) {
    let entries = [...list].map( file => ({
      file,
      id         : _id++, 
      status     : 'pending',
      blobUrl    : null,
      outName    : null,
      error      : null,
      previewUrl : URL.createObjectURL(file),
    }));
    sig.value = [...sig.value, ...entries];
  }
  
  return html`
    <label class='dropzone' onDrop=${onDrop} onDragOver=${onDragOver} onDragLeave=${onDragLeave}>
      <input type="file" accept=${accept} multiple=${multiple} onInput=${onInput} hidden />
      ${icon && html`<iconify-icon icon=${icon} width="96" />`}
      <span>Drop ${what} here or <u>browse</u>.</span>
    </label>`;
}