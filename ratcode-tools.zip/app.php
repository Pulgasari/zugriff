<?php # app.php

require_once __DIR__ . '/global.php';

// App-Slug aus REQUEST_URI extrahieren
// z.B. /image-converter/ → "image-converter"
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri  = trim($path, '/');
$slug = explode('/', $uri)[0];

// Slug validieren: nur a-z, 0-9, - und max. 50 Zeichen
if (!preg_match('/^[a-z0-9-]{1,50}$/', $slug)) {
  http_response_code(400);
  die("Invalid slug.");
}

if (!is_dir(TOOLS_ROOT . "/$slug")) {
  http_response_code(404);
  die("App not found.");
}

/*
if (!$slug || !is_dir(TOOLS_ROOT . "/$slug")) {
  http_response_code(404);
  die("App not found.");
}
*/

$meta = bootstrap_app($slug);

if (!$meta) {
  http_response_code(404);
  die("No app.json found for '$slug'.");
}

echo render_app_template3($meta);
