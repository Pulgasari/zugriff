// xml-minifyer/app.js

import { render } from 'preact';
import { html }   from 'htm/preact'; window.html = html;
import { CodeTransformerApp } from 'tools';

let App = CodeTransformerApp({
  appID       : 'xml-minify',
  lang        : 'xml',
  langExt     : 'xml',
  actionLabel : 'Minify',
  placeholder : 'Paste XML here …',
  execute     : src => {
    const doc = new DOMParser().parseFromString(src, 'application/xml');
    const err = doc.querySelector('parsererror');
    if (err) throw new Error(err.textContent);
    return new XMLSerializer().serializeToString(doc)
      .replace(/>\s+</g, '><')
      .trim();
  },
});

render(html`<${App} />`, document.getElementById('app'));