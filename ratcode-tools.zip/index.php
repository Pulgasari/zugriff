<?php require_once __DIR__ . '/global.php';

// ─── CACHE ───────────────────────────────────────────────────────────────────

function get_apps_cached (): ?array {
  $cacheDir  = DIR_CACHE;
  $cacheFile = "$cacheDir/index.json";

  // Alle app.json-Dateien + ihren mtime sammeln
  $appDirs  = get_app_dirs();
  $maxMtime = 0;
  foreach ($appDirs as $dir) {
    $mtime = filemtime("$dir/app.json");
    if ($mtime > $maxMtime) $maxMtime = $mtime;
  }

  // Cache gültig?
  if (file_exists($cacheFile) && filemtime($cacheFile) >= $maxMtime) {
    return json_decode(file_get_contents($cacheFile), true);
  }

  // Cache aufbauen
  $defaults = json_decode(file_get_contents(__DIR__ . '/.templates/app.json'), true);
  $apps = [];
  foreach ($appDirs as $dir) {
    $override = json_decode(file_get_contents("$dir/app.json"), true);
    $meta     = array_merge($defaults, $override);
    $slug     = basename($dir);
    $meta['path']       = $slug;
    $meta['id']         = $meta['id']         ?: $slug;
    $meta['short_name'] = $meta['short_name'] ?: $meta['name'];
    $apps[] = $meta;
  }

  if (!is_dir($cacheDir)) mkdir($cacheDir, 0755, true);
  file_put_contents($cacheFile, json_encode($apps, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

  return $apps;
}

function get_app_dirs1 (): array {
  $root = DIR_ROOT;
  
  return array_values(array_filter(
    array_map(fn($e) => "$root/$e", scandir($root)),
    fn($path) => is_dir($path)
          && !str_starts_with(basename($path), '.')
          && file_exists("$path/app.json")
  ));
}
function get_app_dirs (): array {
  $root     = DIR_ROOT;
  $entries  = array_map( fn($entry) => "$root/$entry", scandir($root) );
  $filter   = fn($path) => is_dir($path) && !str_starts_with(basename($path), '.') && file_exists("$path/app.json");
  $filtered = array_filter($entries, $filter);
  $values   = array_values($filtered);
  return $values;
}

function get_logo (string $dir): string {
  $svg = "$dir/app.svg";
  if (!file_exists($svg)) return '';
  $content  = file_get_contents($svg);
  $replaced = strtr($content, [ 'height="512"' => '', 'width="512"'  => '' ]);
  return $replaced;
}

// ─── DATA ────────────────────────────────────────────────────────────────────

$apps  = get_apps_cached();
$theme = 'dracula';
?>

<!DOCTYPE html>
<html lang='en' data-theme='<?=$theme?>'>
<head>
  <meta charset='UTF-8'>
  <meta name='viewport' content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>Tools</title>
  <link rel='stylesheet' href='global.css?v=<?=time()?>' />
  <script defer src='https://code.iconify.design/iconify-icon/3.0.0/iconify-icon.min.js'></script>
</head>

<body>
  <div id='app' class='global'>

  <div id='app-head'>
    <div id='app-logo'>
    Ratcode <strong>Tools</strong>
    </div>
  </div>

  <div id='app-body'>
    <ul id='apps'>
    <?php foreach ($apps as $app): ?>
    <?php $logo = get_logo(__DIR__ . '/' . $app['path']); ?>
    <?php $icon = $app['icon'] ?: 'fa-solid:poo'; ?>
    <li>
      <a href='<?=htmlspecialchars($app['path'])?>'>
        <span class='logo'><iconify-icon icon='<?=$icon?>'></iconify-icon></span>
        <span class='title'><?=htmlspecialchars($app['name'])?></span>
      </a>
    </li>
    <?php endforeach ?>
    </ul>
  </div>

  <div id='app-foot'>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4295206593707962" crossorigin="anonymous"></script>
    <!-- Unten -->
    <ins class="adsbygoogle"
      style="display:inline-block; width:480px; height:100px;"
      data-ad-client="ca-pub-4295206593707962"
      data-ad-slot="7606097274"
      ></ins>
    <!--<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>-->
    <!--<script>window.onload = () => (adsbygoogle = window.adsbygoogle || []).push({});</script>-->
    <script>window.addEventListener('load', () => (adsbygoogle = window.adsbygoogle || []).push({}))</script>
    <!--
    data-ad-format="auto"
    data-full-width-responsive="true"
    – Side Project of <a href='https://ratcode.dev'>Ratcode</a> –
    -->
  </div>

  </div>
</body>
</html>