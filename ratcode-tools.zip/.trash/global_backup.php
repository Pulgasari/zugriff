<?php

// Server Lib Autoloader
require_once __DIR__ . '/../lib/php/autoloader.php';

// Show Errors
if (WTF::get('errors') === 'true') {
  ini_set('display_errors', '1');
  ini_set('display_startup_errors', '1');
  error_reporting(E_ALL);
}

########## CONSTANTS ##########

define('TOOLS_ROOT', __DIR__);

const DOMAIN = 'https://tools.ratcode.dev';

const APP_DEFAULT_CHARSET  = 'UTF-8';
const APP_DEFAULT_LANG     = 'en';
const APP_DEFAULT_THEME    = 'dracula';
const APP_DEFAULT_TITLE    = 'Example';
const APP_DEFAULT_VIEWPORT = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';

const HTML_APPNOTE = "<div id='appnote'><p><strong>This App is dumb as fuck.</strong> All its operations are executed in your local environment. Nothing gets uploaded. Any meta-info which gets shared with our servers (which sometimes is needed to provide proper tools) won't get saved in any way.</p></div>";
const HTML_NOTHING = "<div id='app-loading'><iconify-icon icon='svg-spinners:bars-scale-middle' style='color: var(--accent, currentcolor);'></iconify-icon></div>";
const JS_BODY = "<script type='module'>window.onload = () => { 'use strict'; if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js'); };</script>";
const JS_HEAD = '<script type="importmap">
		{ "imports": {
			"tools"             : "https://tools.pulgasari.dev/global.js",
			"bunker"            : "https://cdn.ratcode.dev/js/bunker.js",
		  "iconify"           : "https://code.iconify.design/iconify-icon/3.0.0/iconify-icon.min.js",
			"preact"            : "https://esm.sh/preact@10.19.6",
			"preact/"           : "https://esm.sh/preact@10.19.6/",
			"preact-components" : "https://cdn.ratcode.dev/js/preact-components.js",
			"htm/preact"        : "https://esm.sh/htm@3.1.1/preact?deps=preact@10.19.6",
			"@preact/signals"   : "https://esm.sh/@preact/signals@1.3.0?deps=preact@10.19.6",
			"preact-x"          : "https://cdn.ratcode.dev/js/preact-x.js",
			"ratlib"            : "https://cdn.ratcode.dev/js/ratlib.js"
		}}
	</script>
	<script src="https://code.iconify.design/iconify-icon/3.0.0/iconify-icon.min.js"></script>';

########## BOOTSTRAP MECHANISM ##########

const PWA_DEFAULT_DIR         = 'ltr';
const PWA_DEFAULT_LANG        = 'en';
const PWA_DEFAULT_DISPLAY     = 'standalone';
const PWA_DEFAULT_ORIENTATION = 'portrait';
const PWA_ICONSIZES           = [192, 512];

// MAIN METHOD :: gets called in app.php of an APP
function bootstrap_app (string $appDir): void {
  $meta = get_app_meta($appDir);
  if (!$meta) return;
  maybe_generate_manifest($appDir, $meta);
  maybe_generate_icons($appDir);
}

// gets meta-infos of an APP from global apps.json
function get_app_meta (string $appDir): ?array {
  static $apps = null;
  $apps ??= json_decode(file_get_contents(TOOLS_ROOT . '/apps.json'), true);
  $path = basename($appDir);
  foreach ($apps as $app) {
    if ($app['path'] === $path) return $app;
  }
  return null;
}

// generates manifest.json of an APP base on its meta-infos stored in global apps.json
function maybe_generate_manifest (string $appDir, array $meta): void {
  $out      = "$appDir/manifest.json";
  $template = TOOLS_ROOT . '/.templates/manifest.json';

  if (file_exists($out) && filemtime($out) >= filemtime($template)) return;

  $replacements = [
    '{description}' => $meta['description'] ?? '',
    '{dir}'         => $meta['dir']         ?? PWA_DEFAULT_DIR,
    '{display}'     => $meta['display']     ?? PWA_DEFAULT_DISPLAY,
    '{id}'          => $meta['id']          ?? $meta['path'],
    '{lang}'        => $meta['lang']        ?? PWA_DEFAULT_LANG,
    '{name}'        => $meta['name'],
    '{orientation}' => $meta['orientation'] ?? PWA_DEFAULT_ORIENTATION,
    '{path}'        => $meta['path'],
    '{short_name}'  => $meta['short_name']  ?? $meta['name'],
  ];
  
  $content  = file_get_contents($template);
  $replaced = strtr($content, $replacements);
  file_put_contents($out, $replaced);
}

// generates icons based on the app.svg file of an APP
function maybe_generate_icons (string $appDir): void {
  $svg    = "$appDir/app.svg";
  $assets = "$appDir/assets";
  $out192 = "$assets/icon-192.png";

  if (!file_exists($svg)) return;
  if (file_exists($out192) && filemtime($out192) >= filemtime($svg)) return;

  if (!is_dir($assets)) mkdir($assets, 0755, true);

  copy($svg, "$assets/icon.svg");

  foreach ([192, 512] as $size) {
    $img = new Imagick();
    $img->setBackgroundColor(new ImagickPixel('transparent'));
    $img->setSize($size, $size);
    $img->readImage("svg:$svg");
    $img->setImageFormat('png');
    $img->resizeImage($size, $size, Imagick::FILTER_LANCZOS, 1);
    $img->writeImage("$assets/icon-$size.png");
    $img->clear();
  }
}

########## BOOTSTRAP MECHANISM II ##########

class App {
  public string $id   = '';
  public ?array $meta = null;
  
  public function __construct (string $id) {
    $this->id   = $id;
    $this->meta = $this->getMeta();
  }
  public function getMeta () {
    return get_app_meta($this->id);
  }
}





function useAppTemplate (array $meta, string $type = 'mini') {
  $template = TOOLS_ROOT . "/.templates/app-{$type}.html";

  $replacements = [
    '{charset}'     => $meta['charset']     ?? APP_DEFAULT_CHARSET,
    '{lang}'        => $meta['lang']        ?? APP_DEFAULT_LANG,
    '{logo}'        => $meta['logo']        ?? APP_DEFAULT_TITLE,
    '{theme}'       => $meta['theme']       ?? APP_DEFAULT_THEME,
    '{stylesheets}' => $meta['stylesheets'] ?? '',
    '{title}'       => $meta['title']       ?? APP_DEFAULT_TITLE,
    '{viewport}'    => $meta['viewport']    ?? APP_DEFAULT_VIEWPORT,
  ];
  
  $content  = file_get_contents($template);
  $replaced = strtr($content, $replacements);
  return $replaced;
}