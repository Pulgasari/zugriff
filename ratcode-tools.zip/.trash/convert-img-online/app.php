<?php require_once __DIR__.'/../global.php';

$appcolor  = '#000000';
$theme     = WTF::cookie('theme') ?: 'dracula';
$anticache = WTF::get('ts') === 'off' ? '' : '?v=' . time();
?>
<?php
// POST: Konvertierung
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $file   = $_FILES['file']    ?? null;
    $fmt    = $_POST['format']   ?? 'webp';
    $allowed = ['jpg','jpeg','png','webp','gif','bmp'];

    if (!$file || $file['error'] !== UPLOAD_ERR_OK || !in_array($fmt, $allowed)) {
        http_response_code(400);
        exit('bad request');
    }

    $src = @imagecreatefromstring(file_get_contents($file['tmp_name']));
    if (!$src) { http_response_code(422); exit('unreadable image'); }

    $mime = match($fmt) {
        'jpg','jpeg' => 'image/jpeg',
        'png'        => 'image/png',
        'webp'       => 'image/webp',
        'gif'        => 'image/gif',
        'bmp'        => 'image/bmp',
    };
    header("Content-Type: $mime");

    match($fmt) {
        'jpg','jpeg' => imagejpeg($src, null, 92),
        'png'        => imagepng($src),
        'webp'       => imagewebp($src, null, 90),
        'gif'        => imagegif($src),
        'bmp'        => imagebmp($src),
    };
    imagedestroy($src);
    exit;
}
?>

<?php 
  echo useAppTemplate([
    'logo'  => "<iconify-icon icon='mdi:image-sync-outline'></iconify-icon> Image Converter",
    'title' => 'Image Converter (online)',
  ]);
?>