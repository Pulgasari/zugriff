// convert-img/app.js

import { render } from 'preact';
import { signal } from '@preact/signals';
import { html }   from 'htm/preact'; window.html = html;
import { Dropzone, Icon } from 'tools';

// ── state ────────────────────────────────────────────────────────────────────
const files   = signal([]); // { id, file, status, blobUrl, outName, error }
const format  = signal('webp');
const FORMATS = ['webp', 'png', 'jpg', 'gif'];

// ── helpers ──────────────────────────────────────────────────────────────────
const update = (id, patch) =>
  files.value = files.value.map(f => f.id === id ? { ...f, ...patch } : f);

async function convertOne(entry) {
  update(entry.id, { status: 'converting' });
  try {
    const fd = new FormData();
    fd.append('file', entry.file);
    fd.append('format', format.value);
    const res = await fetch('app.php', { method: 'POST', body: fd });
    if (!res.ok) throw new Error(await res.text());
    const blob    = await res.blob();
    const blobUrl = URL.createObjectURL(blob);
    const outName = entry.file.name.replace(/\.[^.]+$/, '') + '.' + format.value;
    update(entry.id, { status: 'done', blobUrl, outName });
  } catch(e) {
    update(entry.id, { status: 'error', error: e.message });
  }
}

const convertAll = () =>
  Promise.all(files.value.filter(f => f.status === 'pending').map(convertOne));

function downloadAll() {
  files.value.filter(f => f.status === 'done').forEach(f => {
    Object.assign(document.createElement('a'), { href: f.blobUrl, download: f.outName }).click();
  });
}

// ── components ───────────────────────────────────────────────────────────────

function FormatPicker() {
  return html`
    <div class="format-picker">
      ${FORMATS.map(f => html`
        <button class=${'fmt-btn' + (format.value === f ? ' active' : '')} onClick=${() => format.value = f}>
          ${f}
        </button>`)}
    </div>`;
}

function FileItem({ entry: e }) {
  const icon = { pending: 'mdi:image-outline', converting: 'mdi:loading', done: 'mdi:check-circle-outline', error: 'mdi:alert-circle-outline' }[e.status];
  const label = e.status === 'pending' ? '—' : e.status === 'converting' ? 'converting…' : e.status === 'done' ? e.outName : e.error;
  return html`
    <div class=${'file-item ' + e.status}>
      <iconify-icon icon=${icon} class=${e.status === 'converting' ? 'spin' : ''} />
      <span class="name">${e.file.name}</span>
      <span class="label">${label}</span>
      ${e.status === 'done' && html`
        <a class="icon-btn" href=${e.blobUrl} download=${e.outName} title="Download">
          <${Icon} name='download' />
        </a>`}
      ${e.status !== 'converting' && html`
        <button class="icon-btn remove" onClick=${() => files.value = files.value.filter(f => f.id !== e.id)} title="Remove">
          <${Icon} name='close' />
        </button>`}
    </div>`;
}

function App() {
  const list       = files.value;
  const pendingCnt = list.filter(f => f.status === 'pending').length;
  const hasDone    = list.some(f => f.status === 'done');

  return html`
    <div id="app-body">
      <${Dropzone} accept='image/*' icon='mdi:image-plus' multiple=${true} sig=${files} what='images' />
      ${list.length > 0 && html`
        <${FormatPicker} />
        <div class="file-list">
          ${list.map(e => html`<${FileItem} key=${e.id} entry=${e} />`)}
        </div>
        <div class="actions">
          ${pendingCnt > 0 && html`
            <button class="btn primary" onClick=${convertAll}>
              <iconify-icon icon="mdi:cog-outline" /> Convert ${pendingCnt} file${pendingCnt > 1 ? 's' : ''}
            </button>`}
          ${hasDone && html`
            <button class="btn secondary" onClick=${downloadAll}>
              <iconify-icon icon="mdi:download-multiple-outline" /> Download all
            </button>`}
        </div>`}
    </div>`;
}

//render(html`<${App} />`, document.body);
render(html`<${App} />`, document.getElementById('app'));