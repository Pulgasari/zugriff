<?php
// Server Lib Autoloader
require_once __DIR__ . '/../lib/php/autoloader.php';

function getSubdirectories (string $path = '.'): array {
  return array_values(array_filter(
    scandir($path),
    fn($entry) => $entry !== '.' 
               && $entry !== '..' 
               && is_dir("$path/$entry")
               && !str_starts_with($entry, '.')
  ));
}

function getLogo (string $path) {
  $replacements = [
    'height="512"' => '',
    'width="512"'  => '',
  ];
  
  $content  = file_get_contents($path);
  $replaced = strtr($content, $replacements);
  return $replaced;
}

$dirs  = getSubdirectories();
$theme = 'dracula';
?>

<!DOCTYPE html>
<html lang='de' data-theme='<?=$theme?>'>
<head>
  <meta charset='UTF-8'>
  <meta name='viewport' content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <!-- Title -->
  <title>Tools</title>
  <!-- CSS Stylesheets -->
  <link rel='stylesheet' href='global.css?v=<?=time()?>' />
  <!-- JS Scripts -->
	<script src='https://code.iconify.design/iconify-icon/3.0.0/iconify-icon.min.js'></script>
</head>

<body>
  <div id='app' class='global'>
    
    <div id='app-head'>
      <div id='app-logo'>
        Ratcode <strong>Tools</strong>
      </div>
    </div>
    
    <div id='app-body'>
      <ul id='apps'>
      <?php
      foreach ($dirs as $dir) {
        $icon = getLogo("$dir/app.svg");
        echo "<li>
          <span class='logo'>{$icon}</span>
          <a href='{$dir}'>{$dir}</a>
        </li>";
      }
      ?>
      </ul>
    </div>
    
    <div id='app-foot'>
      Are you a rat?
    </div>
    
  </div>
</body>
</html>