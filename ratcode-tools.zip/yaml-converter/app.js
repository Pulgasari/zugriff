// yaml-converter/app.js

import { render } from 'preact';
import { html } from 'htm/preact'; window.html = html;
import { CodeConverterApp } from 'tools';
import { convert } from '../.components/data-converters.js';

let FORMATS = [
  { id: 'csv',  label: 'CSV',  lang: 'plaintext',   ext: 'csv'  },
  { id: 'json', label: 'JSON', lang: 'json',        ext: 'json' },
  { id: 'toml', label: 'TOML', lang: 'toml',        ext: 'toml' },
  { id: 'js',   label: 'JS',   lang: 'javascript',  ext: 'js'   },
];

let App = CodeConverterApp ({
  appID       : 'yaml-converter',
  inputLang   : 'yaml',
  inputExt    : 'yaml',
  placeholder : 'Paste YAML here…',
  actionLabel : 'Convert',
  formats     : FORMATS,
  execute     : (src, fmt) => convert(src, 'yaml', fmt),
});

render(html`<${App} />`, document.getElementById('app'));