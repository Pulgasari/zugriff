// global.js

// Re-Export Components
export { default as Button              } from './.components/Button.js';
export { default as CodeInputPane       } from './.components/CodeInputPane.js';
export { default as CodeOutputPane      } from './.components/CodeOutputPane.js';
export { default as Dropzone            } from './.components/Dropzone.js';
export { default as Icon                } from './.components/Icon.js';
export { default as Picker              } from './.components/Picker.js';
export { default as Slider              } from './.components/Slider.js';
export { default as Toggle              } from './.components/Toggle.js';
export { default as Waveform            } from './.components/Waveform.js';
export { default as WaveformWithHandles } from './.components/WaveformWithHandles.js';

// unsure 
export { default as CopyIcon            } from './.components/CopyIcon.js';
export { default as GhostButton         } from './.components/GhostButton.js';

// Blueprints of Apps
export { default as   CodeConverterApp } from './.components/CodeConverterApp.js';
export { default as CodeTransformerApp } from './.components/CodeTransformerApp.js';
export { default as   DataInspectorApp } from './.components/DataInspectorApp.js';




const SIG = Symbol.for("preact-signals");

function isSignal(x) {
  return !!x && typeof x === "object" && x[SIG] === "Signal";
}

// CSS
export let css = {};
css.setData = (key, value, target) => {
  target ??= document.documentElement;
  let val =  isSignal(value) ? value.value.toString() : value;
  target?.style?.setProperty(key, val);
};
css.setProp = (key, value, target) => {
  target ??= document.documentElement;
  let val =  isSignal(value) ? value.value : value;
  target.dataset[key] = val;
};


/*
let root = document.documentElement;
effect(() => root.style.setProperty('--pxl-scale' , scale.value.toString()));
effect(() => css.setProp('--pxl-scale' , scale.value.toString()));
effect(() => css.setProp('--pxl-scale' , scale));
effect(() => css.setData('showBg' , showBg.value   ? 'true' : 'false'));
effect(() => { root.dataset.showBg   = showBg.value   ? 'true' : 'false' });
effect(() => { root.dataset.showBg   = showBg.value   ? 'true' : 'false' });
*/


/*
(() => {
  let params = new URLSearchParams(location.search);
  let root = document.documentElement;
  for (let [key, value] of params) {
    if (key.startsWith('--')) {
      root.style.setProperty(key, value);
    }
  }
})();
*/
/*
export function voodoo () {
  const MAX_VALUE_LENGTH = 100;
  const BLOCKED = /[;{}]|url\s*\(/i;

  function normalize(value) {
    const trimmed = value.trim();
    if (!trimmed || trimmed.length > MAX_VALUE_LENGTH) return null;
    if (BLOCKED.test(trimmed)) return null;
    return trimmed;
  }

  const params = new URLSearchParams(location.search);
  const root = document.documentElement;

  for (const [key, value] of params) {
    if (!key.startsWith('--')) continue;
    const safe = normalize(value);
    if (safe) root.style.setProperty(key, safe);
  }
}
*/
export function voodoo () {
  let params = new URLSearchParams(location.search);
  let root = document.documentElement;
  for (let [key, value] of params) {
    if (key.startsWith('--')) {
      root.style.setProperty(key, value);
    }
  }
}