import { render } from 'preact';
import { html }   from 'htm/preact'; window.html = html;
import { minify } from 'html-minifier-terser';
import { CodeTransformerApp } from 'tools';

let App = CodeTransformerApp({
  appID       : 'html-minify',
  lang        : 'xml',
  langExt     : 'html',
  actionLabel : 'Minify',
  placeholder : 'Paste HTML here …',
  execute     : src => minify(src, {
    collapseWhitespace            : true,
    removeComments                : true,
    removeRedundantAttributes     : true,
    removeScriptTypeAttributes    : true,
    removeStyleLinkTypeAttributes : true,
    minifyCSS                     : true,
    minifyJS                      : true,
  }),
});

render(html`<${App} />`, document.getElementById('app'));