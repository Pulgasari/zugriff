<?php
$app = $_GET['app'] ?? '';

// App-Ordner muss existieren, kein Path traversal
$appDir = dirname(__DIR__) . '/' . $app;
if (!$app || !is_dir($appDir) || str_contains($app, '..')) {
  http_response_code(404);
  exit;
}

header('Content-Type: application/javascript');
header('Service-Worker-Allowed: /' . $app . '/');

// Optional: tell browser to recheck after 1 hour
header('Cache-Control: max-age=3600');

#readfile(__DIR__ . '/sw.js');

?>

const CACHE = '<?=$app?>-v1';

const PRECACHE = [
  'https://tools.ratcode.dev/global.css',
  'https://tools.ratcode.dev/<?=$app?>/app.css',
  'https://tools.ratcode.dev/<?=$app?>/app.js',
];

// Install: pre-cache the files
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(cache => cache.addAll(PRECACHE))
  );
  self.skipWaiting();
});

// Activate: delete old caches
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Fetch: cache-first with background revalidation (stale-while-revalidate)
self.addEventListener('fetch', e => {
  // Only handle GET requests
  if (e.request.method !== 'GET') return;

  e.respondWith(
    caches.open(CACHE).then( cache =>
      cache.match(e.request).then( cached => {
        const fetchAndUpdate = fetch(e.request).then( response => {
          // Only cache valid responses
          if (response && response.status === 200) {
            cache.put(e.request, response.clone());
          }
          return response;
        });

        // Return cached immediately, revalidate in background
        return cached || fetchAndUpdate;
      })
    )
  );
});
