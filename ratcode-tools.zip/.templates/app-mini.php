<?php
  $uncache = '?v=' . time();
  #$uncache = '';
?>
<!DOCTYPE html>
<html lang='<?=$lang?>' data-theme='<?=$theme?>'>
<head>
  <meta charset='UTF-8'>
  <link rel="manifest" href="manifest.json">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name='viewport' content="<?=$viewport?>">
    <!-- AppColor -->
  <meta name="apple-mobile-web-app-status-bar-style" content="<?=$appcolor?>">
  <meta name="msapplication-TileColor" content="<?=$appcolor?>">
  <meta name="theme-color" content='<?=$appcolor?>' />
  <!-- Icon -->
  <link rel="apple-touch-icon" href="images/hello-icon-152.png">
  <link rel="icon" href="assets/icon.svg" type="image/svg+xml" />
  <meta name="msapplication-TileImage" content="images/hello-icon-144.png">
  <!-- Title -->
  <meta name="apple-mobile-web-app-title" content="<?=$title?>">
  <title><?=$title?></title>
  <!-- CSS -->
  <link rel='stylesheet' href='https://tools.ratcode.dev/global.css<?=$uncache?>' />
  <link rel='stylesheet' href='app.css<?=$uncache?>' />
  <!-- JS -->
  <script type="importmap">
		{ "imports": {
			"tools"                   : "https://tools.ratcode.dev/global.js",
			"bunker"                  : "https://cdn.ratcode.dev/js/bunker.js",
			"iconify"                 : "https://code.iconify.design/iconify-icon/3.0.0/iconify-icon.min.js",
			"preact"                  : "https://esm.sh/preact@10.19.6",
			"preact/"                 : "https://esm.sh/preact@10.19.6/",
			"preact-components"       : "https://cdn.ratcode.dev/js/preact-components.js",
			"htm/preact"              : "https://esm.sh/htm@3.1.1/preact?deps=preact@10.19.6",
			"@preact/signals"         : "https://esm.sh/@preact/signals@1.3.0?deps=preact@10.19.6",
			"preact-x"                : "https://cdn.ratcode.dev/js/preact-x.js",
			"ratlib"                  : "https://cdn.ratcode.dev/js/ratlib.js",
			"transformer"             : "https://cdn.ratcode.dev/js/transformer.js",
			"terser"                  : "https://esm.sh/terser@5.31.1",
      "pdfjs"                   : "https://esm.sh/pdfjs-dist@4.4.168",
      "pdfjs-worker"            : "https://esm.sh/pdfjs-dist@4.4.168/build/pdf.worker.min.mjs",
      "culori"                  : "https://esm.sh/culori@3.3.0",
      "pdf-lib"                 : "https://esm.sh/pdf-lib@1.17.1",
      "yaml"                    : "https://esm.sh/yaml@2.4.5",
      "smol-toml"               : "https://esm.sh/smol-toml@1.3.1",
      "csso"                    : "https://esm.sh/csso@5.0.5",
      "html-minifier-terser"    : "https://esm.sh/html-minifier-terser@7.2.0",
      "highlight.js"            : "https://esm.sh/highlight.js@11.10.0/lib/core",
      "highlight.js/languages/" : "https://esm.sh/highlight.js@11.10.0/lib/languages/"
		}}
	</script>
	<script defer src="https://code.iconify.design/iconify-icon/3.0.0/iconify-icon.min.js"></script>
	<script type='module'>
	  import { voodoo } from 'tools';
	  voodoo();
	</script>
</head>

<body>
  <div id='app'>
    
    <div id='app-body'>
      <div id='app-loading'>
        <iconify-icon icon='svg-spinners:bars-scale-middle' style='color: var(--accent, currentcolor);'></iconify-icon>
      </div>
    </div>
    
    <div id='app-head'>
      <div id='app-logo'><?=$icon ? "<iconify-icon icon='$icon'></iconify-icon>" : ''?><?=$title?>  <span class='badge'>by Ratcode</span></div>
      <div id='actions'>
        <iconify-icon icon='material-symbols:settings'></iconify-icon>
      </div>
    </div>
    
    <div id='app-foot'>
      <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4295206593707962" crossorigin="anonymous"></script>
      <!-- Unten -->
      <ins class="adsbygoogle"
        style="display:inline-block; width:480px; height:100px;"
        data-ad-client="ca-pub-4295206593707962"
        data-ad-slot="7606097274"
        ></ins>
      <script>window.addEventListener('load', () => (adsbygoogle = window.adsbygoogle || []).push({}))</script>
    </div>
    
    <?php if (WTF::get('errorlog') === 'on' || WTF::get('errorlog') === 'true') { ?>
    <style>

    </style>
    <div id='errorlog'></div>
    <script>
      (() => {
        let panel = document.getElementById('errorlog');
        let count = 0;
        
        let clearBtn = document.createElement('button');
        clearBtn.className   = 'err-clear';
        clearBtn.textContent = 'clear';
        clearBtn.onclick     = () => { panel.innerHTML = ''; panel.appendChild(clearBtn); count = 0; };
        panel.appendChild(clearBtn);
        
        function log (msg, src, line, col, type = 'error') {
          count++;
          const entry = document.createElement('div');
          entry.className = 'err-entry';
          entry.innerHTML =
            `<div>[${count}] ${type === 'promise' ? '⚠ unhandled rejection' : '✖ error'}: ${escHtml(msg)}</div>`
            + (src ? `<div class="err-meta">${escHtml(src)}${line != null ? ` ${line}:${col}` : ''}</div>` : '');
          panel.appendChild(entry);
          panel.scrollTop = panel.scrollHeight;
        }
        
        function escHtml (s) {
          return String(s ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
        }
        
        window.onerror = (msg, src, line, col) => { log(msg, src, line, col); return false; };
        window.addEventListener('unhandledrejection', e => {
          let reason = e.reason?.stack ?? e.reason?.message ?? String(e.reason ?? 'unknown');
          log(reason, null, null, null, 'promise');
        });
        
        // also catch console.error
        let _ce = console.error.bind(console);
        console.error = (...args) => { log(args.map(a => typeof a === 'object' ? JSON.stringify(a) : a).join(' '), null, null, null, 'console'); _ce(...args); };
      })();
    </script>
    <?php } ?>
    
  </div>
  
  <!-- [JS] Register Service Worker -->
  <script type='module'>window.onload = () => { 'use strict'; if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js'); };</script>
  <script type='module' src='app.js<?=$uncache?>'></script>
</body>
<html>



