// csv-inspector/app.js

import { render } from 'preact';
import { html } from 'htm/preact'; window.html = html;
import { DataInspectorApp } from 'tools';

// CSV → Array of objects (first row = headers)
function parseCSV (src) {
  let lines = src.trim().split('\n');
  let headers = splitCSVLine(lines[0]);
  return lines.slice(1).filter(l => l.trim()).map(line => {
    let vals = splitCSVLine(line);
    return Object.fromEntries(headers.map((h, i) => [h.trim(), coerce(vals[i]?.trim() ?? '')]));
  });
}

function splitCSVLine (line) {
  let result = [], re = /("([^"]*)"|([^,]*))(,|$)/g;
  let m;
  while ((m = re.exec(line)) !== null) {
    result.push(m[2] ?? m[3] ?? '');
    if (m[4] === '') break;
  }
  return result;
}

function coerce (v) {
  if (v === '')      return null;
  if (v === 'true')  return true;
  if (v === 'false') return false;
  let n = Number(v); return isNaN(n) ? v : n;
}

let App = DataInspectorApp({
  appID       : 'csv-inspector',
  lang        : 'plaintext',
  placeholder : 'Paste CSV here …',
  parse       : parseCSV,
  emptyIcon   : 'mdi:table',
  emptyLabel  : 'Paste CSV and click Inspect',
});

render(html`<${App} />`, document.getElementById('app'));