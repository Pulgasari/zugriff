<?php # global.php

// Server Lib Autoloader
require_once __DIR__ . '/../lib/php/autoloader.php';

// Show Errors
if (WTF::get('errors') === 'true') {
  ini_set('display_errors', '1');
  ini_set('display_startup_errors', '1');
  error_reporting(E_ALL);
}

########## CONSTANTS ##########

define('TOOLS_ROOT', __DIR__);

const DIR_ROOT      = __DIR__;
const DIR_CACHE     = __DIR__ . '/.cache';
const DIR_TEMPLATES = __DIR__ . '/.templates';

// ─── APP META ────────────────────────────────────────────────────────────────

function get_app_meta (string $appSlug): ?array {
  $appJson      = TOOLS_ROOT . "/$appSlug/app.json";
  $defaultsJson = TOOLS_ROOT . '/.templates/app.json';

  if (!file_exists($appJson)) return null;

  $defaults = json_decode(file_get_contents($defaultsJson), true);
  $override = json_decode(file_get_contents($appJson),      true);

  $merged = array_merge($defaults, $override);

  // Felder die sich aus path ableiten wenn nicht explizit gesetzt
  $merged['path']       = $appSlug;
  $merged['id']         = $merged['id']         ?: $appSlug;
  $merged['short_name'] = $merged['short_name'] ?: $merged['name'];

  return $merged;
}


// ─── BOOTSTRAP ───────────────────────────────────────────────────────────────

function bootstrap_app (string $appSlug): ?array {
  $meta = get_app_meta($appSlug);
  if (!$meta) return null;

  $appDir = TOOLS_ROOT . "/$appSlug";
  maybe_generate_manifest($appDir, $meta);
  maybe_generate_icons($appDir, $meta['icon_sizes'] ?? [192, 512]);

  return $meta;
}

// ─── MANIFEST ────────────────────────────────────────────────────────────────

function maybe_generate_manifest (string $appDir, array $meta): void {
  $target   = "$appDir/manifest.json";
  $template = TOOLS_ROOT . '/.templates/manifest.json';

  $appJson = "$appDir/app.json";
  $stale   = !file_exists($target)
    || filemtime($target) < filemtime($template)
    || filemtime($target) < filemtime($appJson);

  if (!$stale) return;

  $replacements = [
    '{description}' => $meta['description'],
    '{dir}'         => $meta['dir'],
    '{display}'     => $meta['display'],
    '{id}'          => $meta['id'],
    '{lang}'        => $meta['lang'],
    '{name}'        => $meta['name'],
    '{orientation}' => $meta['orientation'],
    '{path}'        => $meta['path'],
    '{short_name}'  => $meta['short_name'],
  ];
  
  $content  = file_get_contents($template);
  $replaced = strtr($content, $replacements);
  file_put_contents($target, $replaced);
}

// ─── ICONS ───────────────────────────────────────────────────────────────────

function maybe_generate_icons (string $appDir, array $sizes): void {
  $svg    = "$appDir/app.svg";
  $assets = "$appDir/assets";
  $marker = "$assets/icon-" . min($sizes) . ".png";

  if (!file_exists($svg)) return;
  if (file_exists($marker) && filemtime($marker) >= filemtime($svg)) return;

  if (!is_dir($assets)) mkdir($assets, 0755, true);
  copy($svg, "$assets/icon.svg");

  foreach ($sizes as $size) {
    $img = new Imagick();
    $img->setBackgroundColor(new ImagickPixel('transparent'));
    $img->setSize($size, $size);
    $img->readImage("svg:$svg");
    $img->setImageFormat('png');
    $img->resizeImage($size, $size, Imagick::FILTER_LANCZOS, 1);
    $img->writeImage("$assets/icon-$size.png");
    $img->clear();
  }
}

// ─── TEMPLATE RENDERER ───────────────────────────────────────────────────────

function render_app_template (array $meta): mixed {
  $templateFile = TOOLS_ROOT . "/.templates/app-{$meta['template']}.html";
  if (!file_exists($templateFile)) {
    http_response_code(500);
    die("Template '{$meta['template']}' not found.");
  }

  $replacements = [
    '{appcolor}'    => '#282a36',
    '{lang}'        => $meta['lang'],
    '{theme}'       => $meta['theme'],
    '{title}'       => htmlspecialchars($meta['name']),
    '{logo}'        => $meta['logo']     ?? htmlspecialchars($meta['name']),
    '{viewport}'    => $meta['viewport'],
    '{stylesheets}' => '', // Erweiterbar
  ];
  
  $content  = file_get_contents($templateFile);
  $replaced = strtr($content, $replacements);
  return $replaced;
}
function render_app_template2 (array $meta): string {
  $templateFile = TOOLS_ROOT . "/.templates/app-{$meta['template']}.php";
  if (!file_exists($templateFile)) {
    http_response_code(500);
    die("Template '{$meta['template']}' not found.");
  }

  $replacements = [
    '{appcolor}'    => '#282a36',
    '{lang}'        => $meta['lang'],
    '{theme}'       => $meta['theme'],
    '{title}'       => htmlspecialchars($meta['name']),
    '{logo}'        => $meta['logo'] ?? htmlspecialchars($meta['name']),
    '{viewport}'    => $meta['viewport'],
    '{stylesheets}' => '',
  ];

  ob_start();
  include $templateFile;
  $content = ob_get_clean();

  return strtr($content, $replacements);
}

function render_app_template3 (array $meta): string {
  $templateFile = TOOLS_ROOT . "/.templates/app-{$meta['template']}.php";
  if (!file_exists($templateFile)) {
    http_response_code(500);
    die("Template '{$meta['template']}' not found.");
  }

  // Variablen die im Template verfügbar sein sollen
  $vars = [
    'appcolor'    => '#282a36',
    'icon'        => $meta['icon'] ?? 'fa-solid:poo',
    'lang'        => $meta['lang'],
    'theme'       => $meta['theme'],
    'title'       => htmlspecialchars($meta['name']),
    'logo'        => $meta['logo'] ?? htmlspecialchars($meta['name']),
    'viewport'    => $meta['viewport'],
    'stylesheets' => '',
  ];

  ob_start();
  extract($vars);
  include $templateFile;
  return ob_get_clean();
}