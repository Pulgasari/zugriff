// app.js

import { LoadingIcon } from 'https://cdn.ratcode.dev/js/preact-components.js';
//
import { render } from 'preact';
import { signal } from '@preact/signals';
import { effect } from '@preact/signals';
import { html }   from 'htm/preact';
import ratcode    from '/js/ratcode.js';
//import App     from './components/App.js';
import { disableAndroidKeyboard, enableAndroidKeyboard } from '/components/Keyboard.js';

// Global
window.html    = html;
window.ratcode = ratcode;

// Effects
let root = document.documentElement;
effect(() => root.style.setProperty('--font-size'  , ratcode.config.fontSize.value.toString()) );
effect(() => root.dataset.theme = ratcode.config.theme.value.toString() );
//effect(() => root.dataset.themeHue = themeHue.value.toString() );
effect(() => {
  let forceDisable  = ratcode.config.disableAndroidKeyboard.value;
  let keyboardShown = ratcode.config.showKeyboard.value;

  (forceDisable || keyboardShown) 
    ? disableAndroidKeyboard()
    :  enableAndroidKeyboard();
});

function App ({  }) {
  return html`
    <div id='app'>
      <div id='workspace'>
        ${ratcode.config.showBrowser.value && html`<${Browser}/>`}
        <${Statusbar}/>
        <${FileList}/>
        <${Editor} content=${ratcode.editor.content.value} config=${ratcode.editor.config} />
        ${ratcode.config.showToolbar.value && html`<${Toolbar}/>`}
        ${ratcode.modal.value === 'commands'    && html`<${Commands}/>`}
        ${ratcode.modal.value === 'filebrowser' && html`<${FileBrowser}/>`}
        ${ratcode.modal.value === 'plugins'     && html`<${Plugins}/>`}
        ${ratcode.modal.value === 'settings'    && html`<${Settings}/>`}
        ${ratcode.modal.value === 'workspaces'  && html`<${Workspace}/>`}
      </div>
      <div id='underdock'>
        ${ratcode.config.showKeyboard.value && html`<${Keyboard}/>`}
        <${Dock}/>
      </div>
    </div>
  `;
}

render(
	html`<${App} />`,
	document.body
);


/*
document.addEventListener('DOMContentLoaded', () => {
  let triggers = dom.getElements('[data-action]');
  triggers.forEach(trigger => {
    trigger.addEventListener('click', event => { 
      let value = trigger.getAttribute('data-action');
      if (value) ratcode.exec(value);
    });
  });
});
*/