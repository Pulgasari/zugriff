// sw.js

function importStatement (name, disableCache = false) {
  let str = `import ${name} from '/components/${name}.js`;
  if (disableCache) str += `?v=${Date.now()}`;
  return `${str}';`
}

self.addEventListener( 'install'  , event => self.skipWaiting());
self.addEventListener( 'activate' , event => event.waitUntil(self.clients.claim()));

self.addEventListener('fetch', (event) => {
  let url = new URL(event.request.url);
  // ignore external CDNs and non-JS files
  if (url.origin !== self.location.origin) return;
  if (!url.pathname.endsWith('.js')) return;
  //
  event.respondWith((async () => {
    try {
      let response = await fetch(url.href); if (!response.ok) return response;
      let code     = await response.text();
      let imports  = [];
      let currentFile = url.pathname.split('/').pop().replace('.js', '');
      // auto-import signal
      if (/signal\s*\(/.test(code) && !code.includes('import { signal }')) {
        imports.push(`import { signal } from '@preact/signals';`);
      }
      // auto-import local components (e.g., <${Dock})
      let matches = [...code.matchAll(/<\$\{([A-Z]\w+)/g)];
      if (matches.length > 0) {
        let components = [...new Set(matches.map( m => m[1] ))];
        components.forEach( name => {
          if (name === currentFile) return; // skip self-import
          if (!code.includes(`import ${name}`)) {
            imports.push( importStatement(name, true) );
          }
        });
      }
      // inject auto-imports
      if (imports.length > 0) code = `${imports.join('\n')}\n\n${code}`;
      //
      return new Response( code, {
        headers: { 
          'Content-Type'  : 'application/javascript',
          'Cache-Control' : 'no-cache' // for dev
        }
      });
    } catch (error) {
      console.error(`Auto-Import failed for ${url.href}:`, error);
      return fetch(event.request);
    }
  })());
});