// components/TreeNode.js

import { useEffect, useState, useCallback } from 'preact/hooks';

export default function TreeNode ({ entry, depth = 0 }) {
  let [ children  , setChildren  ] = useState([]);
  let [ isLoaded  , setIsLoaded  ] = useState(false);
  let [ isLoading , setIsLoading ] = useState(false);
  let [ isOpen    , setIsOpen    ] = useState(false);
  let isDir  = entry.kind === 'directory';
  let indent = depth * 16;

  let loadChildren = async () => {
    if (isLoaded) return;
    setIsLoading(true);
    let entries = [];
    for await (let child of entry.values()) entries.push(child);
    entries.sort((a, b) => {
      if (a.kind === b.kind) return a.name.localeCompare(b.name);
      return a.kind === 'directory' ? -1 : 1;
    });
    setChildren(entries);
    setIsLoaded(true);
    setIsLoading(false);
  };

  let toggle = async () => {
    if (!isDir) return;
    if (!isOpen) await loadChildren();
    setIsOpen(v => !v);
  };

  let openFile = async () => {
    if (isDir) return;
    // Bereits offen? Nur aktivieren
    let existing = ratcode.openFiles.value.find(f => f.handle === entry);
    if (existing) { ratcode.activeFile.value = existing; return; }
    // Datei lesen
    let file    = await entry.getFile();
    let content = await file.text();
    // Sprache aus Extension ableiten
    let ext     = entry.name.split('.').pop();
    let lang    = { js:'javascript', ts:'typescript', json:'json', css:'css', html:'html', md:'markdown' }[ext] ?? 'plaintext';
    let fileObj = { handle: entry, name: entry.name, content, language: lang, isDirty: false };
    //
    ratcode.openFiles.value  = [...ratcode.openFiles.value, fileObj];
    ratcode.activeFile.value = fileObj;
    ratcode.closeModal();
  };
  
  return html`
    <li class="tree-node ${isDir ? 'is-dir' : 'is-file'}">
      <div
        class="tree-row ${isDir ? 'clickable' : ''}"
        style="padding-left: ${indent + 6}px"
        onClick=${isDir ? toggle : openFile}
      >
        ${isDir && html`
          <span class="tree-arrow ${isOpen ? 'open' : ''}">
            <${Icon} name=${isLoading ? 'material-symbols:progress-activity' : 'material-symbols:chevron-right'}
              size="16"
            />
          </span>
        `}
        ${!isDir && html`<span class="tree-arrow-spacer" />`}
        
        <${Icon}
          name=${isDir ? (isOpen ? 'folder-open' : 'folder') : 'file'}
          color=${isDir ? '#f6c744' : '#888'}
          size="16"
        />
        <span class="tree-name">${entry.name}</span>
      </div>

      ${isOpen && isLoaded && html`
        <ul class="tree-children">
          ${children.length === 0
            ? html`<li class='tree-empty'>Leer</li>`
            : children.map(child => html`<${TreeNode} key=${child.name} entry=${child} depth=${depth + 1} />`)
          }
        </ul>
      `}
    </li>
  `;
}