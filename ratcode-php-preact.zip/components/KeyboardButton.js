// components/KeyboardButton.js

export default function KeyboardButton ({ keyValue, icon, label, className = '', active = false, disabled = false, onAction }) {
  let displayContent = icon ? html`<${Icon} name=${icon}/>` : (label || keyValue);
  let onmousedown    = event => { event.preventDefault(); if (!disabled) onAction(keyValue); };

  return html`
    <button 
      class=${className} 
      disabled=${disabled}
      onmousedown=${onmousedown}
      data-active=${active} 
      tabindex="-1"
    >
      ${displayContent}
    </button>
  `;
};