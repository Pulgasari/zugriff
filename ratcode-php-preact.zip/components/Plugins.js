// components/Plugins.js (Modal)

export default function Plugins ({}) {
  return html`
    <${Modal} title='Plugins'>
      Plugins
    </${Modal}>
  `;
};