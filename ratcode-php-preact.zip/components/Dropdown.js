// components/Dropdown.js

export default function Dropdown ({ onChange, options, selected }) {
  return html`
    <select onChange=${onChange} value=${selected}>
      ${options.map(opt => {
        let label = Array.isArray(opt) ? opt[0] : opt;
        let value = Array.isArray(opt) ? opt[1] : opt;
        return html`<option value=${value}>${label}</option>`;
      })}
    </select>
  `;
}