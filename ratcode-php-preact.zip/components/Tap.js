// components/Tap.js

export default function Tap ({ cmd, icon, className }) {
  return html`
    <div onClick=${() => ratcode.exec(cmd)} className=${className}>
      <${Icon} name=${icon} />
    </div>
  `;
}