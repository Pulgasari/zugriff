// components/App.js

export default function App ({}) {
  return html`
    <div id='app'>
      <div id='workspace'>
        <${Statusbar}/>
        <${FileList}/>
        <${Editor}/>
      </div>
      <div id='underdock'>
        <${Toolbar}/>
        ${showKeyboard.value && html`<${Keyboard}/>`}
        <${Dock}/>
      </div>
    </div>
  `;
}