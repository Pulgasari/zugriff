// components/Commands.js

import { useState } from 'preact/hooks';
import { signalWithStorage } from 'preact-x';

export let favoritesSignal = signalWithStorage([], 'ratcode-favs');

export default function Commands ({}) {
  let [search, setSearch] = useState('');
  let favorites = favoritesSignal.value;

  let toggleFavorite = (event, key) => {
    event.stopPropagation();
    // Update Signal
    favoritesSignal.value = favorites.includes(key) 
      ? favorites.filter(k => k !== key) 
      : [...favorites, key];
  };

  let executeCommand = key => { ratcode.modal.value = null; ratcode.exec(key); };

  // 1. Alle durchsuchen
  let filteredCommands = Array.from(ratcode.commands.entries()).filter(([key, cmd]) => {
    let query     = search.toLowerCase();
    let matchKey  = key.toLowerCase().includes(query);
    let matchName = cmd.name && cmd.name.toLowerCase().includes(query);
    return matchKey || matchName;
  });

  // 2. In zwei Listen aufteilen
  let favCommands     = filteredCommands.filter( ([key]) =>  favorites.includes(key));
  let regularCommands = filteredCommands.filter( ([key]) => !favorites.includes(key));

  // Hilfsfunktion
  let renderItem = ([key, cmd]) => {
    let isFav = favorites.includes(key);
    return html`
      <li onClick=${() => executeCommand(key)}>
        <strong>${cmd.name || 'Ohne Namen'}</strong>
        <small>${key}</small>
        
        <div className="fav-btn" onClick=${event => toggleFavorite(event, key)}>
          <${Icon} 
            name=${isFav ? 'bxs:heart' : 'bx:heart'} 
            color=${isFav ? 'var(--accent, currentcolor)' : 'currentColor'} 
          />
        </div>
      </li>
    `;
  };

  return html`
    <${Modal} id='commands' title='Commands'>
      <div className="commands-header">
        <input 
          type="text" 
          placeholder="Commands durchsuchen..." 
          value=${search}
          onInput=${event => setSearch(event.target.value)}
          autoFocus
        />
      </div>

      <div className="commands-body">
        <h3>Favoriten</h3>
        ${favCommands.length > 0 && html`
          <ul className="commands-list favorites">
            ${favCommands.map(renderItem)}
          </ul>
        `}
        
        <h3>Alle</h3>
        ${regularCommands.length > 0 && html`
          <ul className="commands-list">
            ${regularCommands.map(renderItem)}
          </ul>
        `}

        ${filteredCommands.length === 0 && html`
          <p className='none'>Keine Commands gefunden.</p>
        `}
      </div>
    </${Modal}>
  `;
};