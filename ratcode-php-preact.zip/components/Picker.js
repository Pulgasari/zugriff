// components/Picker.js

export default function Picker({ callback, options, value }) {
  return html`
    <div class='picker'>
      ${options.map(opt => {
        return html`
          <button class=${(opt === value) ? 'active' : ''} onClick=${() => callback(opt)}>${opt}</button>
        `;
      })}
    </div>
  `;
}