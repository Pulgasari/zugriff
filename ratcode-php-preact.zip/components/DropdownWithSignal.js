// components/DropdownWithSignal.js

export default function DropdownWithSignal ({ options, signal }) {
  let onChange = event => signal.value = event.target.value;
  return html`<${Dropdown} ...${{ options, onChange }} selected=${signal.value} />`;
}