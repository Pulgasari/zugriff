// components/Welcome.js

export default function Welcome () {
  return html`
    <div id='welcome'>
      <${Logo} size='200' />
      <div>
        <${Icon} name="material-symbols:info" size="24" />
        <span onClick=${() => ratcode.toggleModal('filebrowser')}>
          Keine Datei ausgewählt.
        </span>
      </div>
    </div>
  `;
};