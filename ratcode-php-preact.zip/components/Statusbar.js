// components/Statusbar.js

export default function Statusbar ({}) {
  let file    = ratcode.activeFile.value;
  let config  = ratcode.editor.config;
  let sizeFormat = ratcode.config.fileSizeFormat.value;
  let { toggleConfig } = ratcode.editor;
  
  let formatSize = bytes => {
    if (bytes < 1024)        return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  let cycleSize = () => {
    let modes = ['formatted', 'bytes', 'chars'];
    let next  = modes[(modes.indexOf(sizeFormat) + 1) % modes.length];
    ratcode.config.fileSizeFormat.value = next;
  };

  let getFileSize = () => {
    if (!file) return null;
    let bytes = new Blob([file.content]).size;
    if (sizeFormat === 'formatted') return formatSize(bytes);
    if (sizeFormat === 'bytes')     return `${bytes} B`;
    if (sizeFormat === 'chars')     return `${file.content.length} chars`;
  };

  //let fileSize  = file ? formatSize(new Blob([file.content]).size) : null;
  let indentStr = config.insertSpaces === false ? 'Tabs' : `Spaces: ${config.tabSize ?? 2}`;
  let wordWrap  = config.wordWrap      !== 'off' ?  'Wrap: on' :  'Wrap: off';
  let lineNums  = config.lineNumbers   === 'on'  ? 'Lines: on' : 'Lines: off';
  let minimap   = config.minimap.enabled         ?   'Map: on' :   'Map: off';

  return html`
    <div id='statusbar'>
      ${file ? html`
        <span class="sb-item sb-language">${file.language}</span>
        <span class="sb-sep">·</span>
        <span class="sb-item sb-size" onClick=${cycleSize}>${getFileSize()}</span>
        <span class="sb-sep">·</span>
        <span class="sb-item sb-indent" onClick=${() => ratcode.modal.value = 'settings'}>
          ${indentStr}
        </span>
      ` : html`<span class="sb-item sb-empty">Keine Datei</span>`}
      
      <span class="sb-spacer" />
      
      <span class="sb-item sb-nowrap" onClick=${() => toggleConfig('wordWrap')}>${wordWrap}</span>
      <span class="sb-sep">·</span>
      <span class="sb-item" onClick=${() => toggleConfig('minimap.enabled')}>${minimap}</span>
      <span class="sb-sep">·</span>
      <span class="sb-item" onClick=${() => toggleConfig('lineNumbers')}>${lineNums}</span>
      <span class="sb-sep">·</span>
      <span class="sb-item sb-fontsize">${config.fontSize}px</span>
    </div>
  `;
}

/*
<span class="sb-item sb-name">${file.name}${file.isDirty ? ' ●' : ''}</span>
*/