// components/FileBrowser.js

import { useEffect, useState, useCallback } from 'preact/hooks';
import fs from '/js/fs.js';

export let filesSignal = signal([]);
let statusSignal       = signal('init');
let errorSignal        = signal(null);
let savedHandleSignal  = signal(null);

export default function FileBrowser ({}) {
  let files       = filesSignal.value;
  let status      = statusSignal.value;
  let errorMsg    = errorSignal.value;
  let savedHandle = savedHandleSignal.value;

  let applyDirectory = (handle, entries) => {
    filesSignal.value        = entries;
    ratcode.files            = entries;
    ratcode.currentDirHandle = handle;
    savedHandleSignal.value  = handle;
    statusSignal.value       = 'ready';
  };
  let loadDirectoryContents = async (dirHandle) => {
    let entries = await fs.readDir(dirHandle);
    applyDirectory(dirHandle, entries);
  };
  let clearWorkspace = async () => {
    try {
      await fs.clearRoot();
      // State resetten
      filesSignal.value        = [];
      ratcode.files            = [];
      ratcode.currentDirHandle = null;
      savedHandleSignal.value  = null;
      statusSignal.value       = 'idle';
      errorSignal.value        = null;
      
      console.info('[FS] workspace cleared');
    } catch (e) {
      console.error(e);
      errorSignal.value  = 'Konnte Workspace nicht löschen';
      statusSignal.value = 'error';
    }
  };
  
  useEffect(() => {
    if (statusSignal.peek() !== 'init') return;
    
    let init = async () => {
      try {
        let handle = await fs.getSavedRoot();
        if (!handle) {
          statusSignal.value = 'idle';
          return;
        }
        let ok = await fs.ensureReadPermission(handle);
        if (!ok) {
          savedHandleSignal.value = handle; // nur hier nötig für UI
          statusSignal.value = 'needs-restore';
          return;
        }
        let entries = await fs.readDir(handle);
        applyDirectory(handle, entries);
      } catch (e) {
        statusSignal.value = 'error';
        errorSignal.value  = 'Init failed';
      }
    };
  
    init();
  }, []);

  let openDirectory = async () => {
    errorSignal.value = null;
    try {
      let dirHandle = await window.showDirectoryPicker({ mode: 'readwrite' });
      await fs.setRoot(dirHandle);
      let entries = await fs.readDir(dirHandle);
      applyDirectory(dirHandle, entries);
    } catch (e) {
      if (e.name !== 'AbortError') {
        errorSignal.value  = 'Ordner konnte nicht geöffnet werden.';
        statusSignal.value = 'error';
      }
    }
  };
  let restoreDirectory = async () => {
    let handle = savedHandleSignal.peek();
    if (!handle) return;
    let ok = await fs.ensureReadPermission(handle);
    if (ok) {
      let entries = await fs.readDir(handle);
      applyDirectory(handle, entries);
      return;
    }
    try {
      let newHandle = await window.showDirectoryPicker({ startIn: handle });
      await fs.setRoot(newHandle);
      let entries = await fs.readDir(newHandle);
      applyDirectory(newHandle, entries);
    } catch (e) {
      if (e.name !== 'AbortError') {
        errorSignal.value  = 'Restore fehlgeschlagen';
        statusSignal.value = 'error';
      }
    }
  };

  return html`
    <${Modal} id='filebrowser' title='File Browser'>

      <div class="filebrowser-header">
        <button onClick=${clearWorkspace} class="btn-secondary btn-danger">
          Reset Workspace
        </button>
        <button onClick=${openDirectory} class="btn-primary">
          <${Icon} name="material-symbols:folder-open" />
          Neuen Ordner freigeben
        </button>
        ${status === 'needs-restore' && savedHandle && html`
          <button onClick=${restoreDirectory} class="btn-secondary btn-accent">
            <${Icon} name="material-symbols:folder-open" />
            "${savedHandle.name}" öffnen
          </button>
        `}
      </div>

      ${errorMsg && html`
        <div class="filebrowser-error">
          <${Icon} name="material-symbols:error-outline" size="16" />
          ${errorMsg}
        </div>
      `}

      <div class="filebrowser-body">
        ${status === 'init' && html`
          <div class="none">
            <${Icon} name="material-symbols:hourglass-empty" size="24" /><br/>
            Lade gespeicherte Sitzung…
          </div>
        `}
        ${status === 'needs-restore' && html`
          <div class="none">
            <${Icon} name="material-symbols:lock-outline" size="24" /><br/>
            Klicke auf "Wiederherstellen", um<br/>
            <strong>${savedHandle?.name}</strong> zu reaktivieren.
          </div>
        `}
        ${(status === 'ready' || status === 'idle') && html`
          ${files.length === 0
            ? html`
                <div class="none">
                  <${Icon} name="material-symbols:info" size="24" /><br/>
                  Kein Ordner geladen.
                </div>
              `
            : html`
                <ul class="tree-root">
                  ${files.map(entry => html`
                    <${TreeNode} key=${entry.name} entry=${entry} depth=${0} />
                  `)}
                </ul>
              `
          }
        `}
      </div>

    </${Modal}>
  `;
}