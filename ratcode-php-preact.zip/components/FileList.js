// components/FileList.js

export default function FileList({}) {
  let openFiles  = ratcode.openFiles.value;
  let activeFile = ratcode.activeFile.value;

  let activate = (file) => {
    ratcode.activeFile.value = file;
  };

  let close = (file, e) => {
    e.stopPropagation();
    let rest = ratcode.openFiles.value.filter(f => f !== file);
    ratcode.openFiles.value = rest;
    // War das der aktive Tab? Dann letzten öffnen oder null
    if (ratcode.activeFile.value === file) {
      ratcode.activeFile.value = rest.at(-1) ?? null;
    }
  };

  return html`
    <div id='filelist'>
      ${openFiles.length === 0
        ? html`<div class="filelist-empty">Keine Dateien geöffnet</div>`
        : openFiles.map(file => html`
            <div
              class="file-tab ${file === activeFile ? 'active' : ''}"
              onClick=${() => activate(file)}
            >
              <${Icon} name="material-symbols:description" size="14" color="#888" />
              <span class="tab-name">${file.name}</span>
              ${file.isDirty && html`<span class="tab-dirty">●</span>`}
              <button class="tab-close" onClick=${(e) => close(file, e)}>
                <${Icon} name="material-symbols:close" size="14" />
              </button>
            </div>
          `)
      }
    </div>
  `;
}