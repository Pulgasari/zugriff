// components/Workspace.js

export default function Workspace ({}) {
  return html`
    <${Modal} title='Workspaces'>
      ...
    </${Modal}>
  `;
}