// components/Keyboard.js

import { useEffect, useState } from 'preact/hooks';

// Globale Layout-Konfiguration
let layouts = {
  de: {
    regular : [ 'qwertzuiopü', 'asdfghjklöä', '--yxcvbnm--' ],
    shift   : [ 'QWERTZUIOPÜ', 'ASDFGHJKLÖÄ', '--YXCVBNM--' ],
    symbols : [ `([{<?.,'$#=+*12345`, `)]}>!:;"&|_-/67890` ]
  }
};

// Treatment of Android Keyboard
// Selektoren aller Elemente die normalerweise die Tastatur triggern
let KB_SELECTOR = 'input, textarea, [contenteditable]';
let setManual   = el => el.setAttribute('virtualkeyboardpolicy', 'manual');
let setAuto     = el => el.removeAttribute('virtualkeyboardpolicy');
let observer    = null;
/*
let $EditorTA = document.querySelector('#editor-container .editor-content');
let disableAndroidKeyboard = () => {
  $EditorTA?.setAttribute('virtualkeyboardpolicy', 'manual');
  if (navigator.virtualKeyboard) navigator.virtualKeyboard.hide();
};
let enableAndroidKeyboard = () => {
  $EditorTA?.setAttribute('virtualkeyboardpolicy', 'auto');
  if (navigator.virtualKeyboard) navigator.virtualKeyboard.show();
};
*/
export let disableAndroidKeyboard = () => {
  if (!navigator.virtualKeyboard) return;
  navigator.virtualKeyboard.overlaysContent = true;
  // handle existing dom elements
  document.querySelectorAll(KB_SELECTOR).forEach(setManual);
  // handle future dom elements
  observer = new MutationObserver(mutations => {
    for (let { addedNodes } of mutations) {
      for (let node of addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.matches?.(KB_SELECTOR))        setManual(node);
        node.querySelectorAll?.(KB_SELECTOR).forEach(setManual);
      }
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
  // backup
  document.addEventListener('focusin', onFocusIn, true);
};
export let enableAndroidKeyboard  = () => {
  if (!navigator.virtualKeyboard) return;
  navigator.virtualKeyboard.overlaysContent = false;
  document.querySelectorAll(KB_SELECTOR).forEach(setAuto);
  observer?.disconnect();
  observer = null;
  document.removeEventListener('focusin', onFocusIn, true);
};
let onFocusIn = () => navigator.virtualKeyboard?.hide();

export default function Keyboard () {
  let [ layoutCode     , setLayoutCode     ] = useState('de');
  let [ isShiftPressed , setIsShiftPressed ] = useState(false);
  let [ isCapsLock     , setIsCapsLock     ] = useState(false);
  let [ isAltPressed   , setIsAltPressed   ] = useState(false);
  let [ isCtrlPressed  , setIsCtrlPressed  ] = useState(false);

  // Lifecycle für Android Keyboard Management
  /*
  useEffect(() => {
    disableAndroidKeyboard();
    return () => enableAndroidKeyboard();
  }, []);
  */
  useEffect(() => {
    return () => {
      if (!ratcode.config.disableAndroidKeyboard.value) enableAndroidKeyboard();
    };
  }, []);

  let specialKeys = ['alt', 'backspace', 'capslock', 'ctrl', 'enter', 'shift', 'space', 'tab', 'tab-rtl', 'left', 'right', 'up', 'down'];
  let isSpecial   = key => specialKeys.includes(key);

  let dispatchKey = (key, options = {}) => {
    let target = document.activeElement;
    if (!target) return;
    
    let eventConfig = {
      key        : key,
      shiftKey   : isShiftPressed || isCapsLock,
      ctrlKey    : isCtrlPressed,
      altKey     : isAltPressed,
      bubbles    : true,
      cancelable : true,
      ...options
    };
    
    let keydownEvent = new KeyboardEvent('keydown', eventConfig);
    let keyupEvent   = new KeyboardEvent('keyup', eventConfig);
    
    target.dispatchEvent(keydownEvent);
    
    if (key.length === 1 && !isCtrlPressed && !isAltPressed) {
      if (['INPUT', 'TEXTAREA'].includes(target.tagName)) {
        let start = target.selectionStart;
        let end   = target.selectionEnd;
        target.value = target.value.slice(0, start) + key + target.value.slice(end);
        target.selectionStart = target.selectionEnd = start + key.length;
        target.dispatchEvent(new Event('input', { bubbles: true }));
      }
    }
    
    target.dispatchEvent(keyupEvent);
    
    // Reset shift if not in CapsLock
    if (isShiftPressed && !isCapsLock) {
      setIsShiftPressed(false);
    }
  };

  let handleSpecialKey = action => {
    switch (action) {
      case 'shift':
        setIsShiftPressed(!isShiftPressed);
        break;
      case 'capslock':
        setIsCapsLock(!isCapsLock);
        setIsShiftPressed(false);
        break;
      case 'backspace' : dispatchKey('Backspace',  { keyCode:  8 }); break;
      case 'enter'     : dispatchKey('Enter',      { keyCode: 13 }); break;
      case 'tab'       : dispatchKey('Tab',        { keyCode:  9 }); break;
      case 'space'     : dispatchKey(' ',          { keyCode: 32 }); break;
      case 'left'      : dispatchKey('ArrowLeft',  { keyCode: 37 }); break;
      case 'right'     : dispatchKey('ArrowRight', { keyCode: 39 }); break;
      case 'up'        : dispatchKey('ArrowUp',    { keyCode: 38 }); break;
      case 'down'      : dispatchKey('ArrowDown',  { keyCode: 40 }); break;
    }
  };

  let handleAction = key => isSpecial(key) ? handleSpecialKey(key) : dispatchKey(key);

  // Render Logik Vorbereitung
  let isShifted    = isShiftPressed || isCapsLock;
  let layout       = layouts[layoutCode];
  let currentAlpha = isShifted ? layout.shift : layout.regular;
  let normalizeRow = row => typeof row === 'string' ? row.split('') : row;
  let renderRow = (row, rowIndex, type = 'alpha') => {
    let chars = normalizeRow(row);
    return html`
      <div class="row">
        ${type === 'alpha' && rowIndex === 0 && html`<${KeyboardButton} keyValue="tab"      icon="tab"      className="w-2" onAction=${handleAction} />`}
        ${type === 'alpha' && rowIndex === 1 && html`<${KeyboardButton} keyValue="capslock" icon="capslock" className="w-2" onAction=${handleAction} active=${isCapsLock} />`}
        ${type === 'alpha' && rowIndex === 2 && html`<${KeyboardButton} keyValue="shift"    icon="shift"    className="w-2" onAction=${handleAction} active=${isShiftPressed} />`}
        
        ${chars.map((char, index) => {
          return (char === '–' || char === ' ') 
          ? html`<div key=${index} class="keyboard-spacer"></div>`
          : html`<${KeyboardButton} key=${index} keyValue=${char} className=${type === 'symbol' ? 'symbol' : ''} onAction=${handleAction} />`;
        })}
        
        ${type === 'alpha' && rowIndex === 0 && html`<${KeyboardButton} keyValue="tab-rtl"   icon="tab-rtl"   className="w-2" onAction=${handleAction} />`}
        ${type === 'alpha' && rowIndex === 1 && html`<${KeyboardButton} keyValue="backspace" icon="backspace" className="w-2" onAction=${handleAction} />`}
        ${type === 'alpha' && rowIndex === 2 && html`<${KeyboardButton} keyValue="enter"     icon="enter"     className="w-2" onAction=${handleAction} />`}
      </div>
    `;
  };

  return html`
    <div id="keyboard">
      <div id="keyboard-symbols">
        ${layout.symbols.map((row, i) => renderRow(row, i, 'symbol'))}
      </div>
      <div id="keyboard-keys">
        ${currentAlpha.map((row, i) => renderRow(row, i, 'alpha'))}
        <div class="row">
          <${KeyboardButton} keyValue="ctrl" className="alt w-2" disabled=${true} onAction=${handleAction} />
          <${KeyboardButton} keyValue="alt" className="alt w-2" disabled=${true} onAction=${handleAction} />
          <${KeyboardButton} keyValue="space" icon="space" className="space w-7" onAction=${handleAction} />
          <${KeyboardButton} keyValue="up"    icon="arrow-up" onAction=${handleAction} />
          <${KeyboardButton} keyValue="down"  icon="arrow-down" onAction=${handleAction} />
          <${KeyboardButton} keyValue="left"  icon="arrow-left" onAction=${handleAction} />
          <${KeyboardButton} keyValue="right" icon="arrow-right" onAction=${handleAction} />
        </div>
      </div>
    </div>
  `;
}

