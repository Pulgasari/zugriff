// components/Dock.js

export default function Dock ({}) {
  return html`
    <div id='dock'>
      <div className='section'>
        <${Tap} cmd='settings:toggle'    icon='settings'          className=${ratcode.modal.value === 'settings'    && 'active'} />
        <${Tap} cmd='plugins:toggle'     icon='gridicons:plugins' className=${ratcode.modal.value === 'plugins'     && 'active'} />
        <${Tap} cmd='filebrowser:toggle' icon='mdi:file-tree'     className=${ratcode.modal.value === 'filebrowser' && 'active'} />
        <${Tap} cmd='workspaces:toggle'  icon='workspaces'        className=${ratcode.modal.value === 'workspaces'  && 'active'} />
      </div>
      <div className='section'>
        <${Tap} cmd='editor:redo'     icon='bx:redo' />
        <${Tap} cmd='commands:toggle' icon='bx:command' className=${(ratcode.modal.value === 'commands') && 'active'} />
        <${Tap} cmd='editor:undo'     icon='bx:undo' />
      </div>
      <div className='section'>
        <${Tap} cmd='browser:toggle'  icon='mynaui:globe' className=${ratcode.config.showBrowser.value && 'active'} />
        <${Tap} cmd='keyboard:toggle' icon='bxs:keyboard' className=${ratcode.config.showKeyboard.value && 'active'} />
        <${Tap} cmd='toolbar:toggle'  icon='mdi:tools'    className=${ratcode.config.showToolbar.value && 'active'} />
      </div>
    </div>
  `;
};