// components/Icon.js

//import icons from '../data/icons.json';
//import icons from '/data/icons.json' with { type: 'json' };

let icons = JSON.parse(`{
  "add": "material-symbols:add",
  "remove": "material-symbols:remove",
  "arrow-down": "material-symbols:arrow-downward",
  "arrow-left": "material-symbols:arrow-back",
  "arrow-right": "material-symbols:arrow-forward",
  "arrow-up": "material-symbols:arrow-upward",
  "backspace": "material-symbols:backspace",
  "blockindent": "material-symbols:keyboard-tab",
  "blockoutdent": "material-symbols:keyboard-tab-rtl",
  "capslock": "material-symbols:keyboard-capslock",
  "close": "fa:close",
  "commands": "material-symbols:keyboard-command-key",
  "copy": "bx:copy",
  "copy-all": "material-symbols:copy-all",
  "copy-file": "material-symbols:file-copy",
  "copy-lines-down": "material-symbols:move-down",
  "copy-lines-up": "material-symbols:move-up",
  "cut": "material-symbols:cut",
  "deselect": "material-symbols:deselect",
  "enter": "material-symbols:keyboard-return",
  "join-lines": "material-symbols:join-outline",
  "keyboard": "tdesign:keyboard",
  "move-lines-down": "material-symbols:text-select-move-down",
  "move-lines-up": "material-symbols:text-select-move-up",
  "move-selection-down": "material-symbols:move-selection-down",
  "move-selection-up": "material-symbols:move-selection-up",
  "paste": "material-symbols:content-paste",
  "previewer": "material-symbols:preview",
  "redo": "bx:redo",
  "refresh": "material-symbols:refresh",
  "save": "material-symbols:file-save",
  "search": "material-symbols:search",
  "select-all": "material-symbols:select-all",
  "settings": "material-symbols:settings",
  "shift": "material-symbols:shift",
  "sort-lines": "material-symbols:reorder",
  "space": "material-symbols:space-bar",
  "split-line": "material-symbols:split-scene-outline",
  "tab": "bx:arrow-to-right",
  "tab-rtl": "bx:arrow-to-left",
  "toggle-off": "material-symbols:toggle-off",
  "toggle-on": "material-symbols:toggle-on",
  "toolbar": "material-symbols:widgets",
  "undo": "bx:undo",
  "lineheight": "material-symbols:format-line-spacing",
  "fontsize": "material-symbols:format-size",
  "workspaces": "grommet-icons:projects",
  "file": "material-symbols:description",
  "folder": "material-symbols:folder",
  "folder-open": "material-symbols:folder-open"
}`);

export default function Icon ({ name, size, color = 'currentColor' }) {
  let icon  = name.includes(':') ? name : (icons[name] || 'material-symbols:help');
  let style = { color };
  if (size) style.fontSize = `${size}px`;
  return html`<iconify-icon className='icon' icon=${icon} style=${style}></iconify-icon>`;
}