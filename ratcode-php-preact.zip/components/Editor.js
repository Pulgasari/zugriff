// components/Editor.js

import { useEffect, useRef } from 'preact/hooks';
import * as Monaco  from 'https://esm.sh/monaco-editor@0.50.0?bundle';
import EditorWorker from 'https://esm.sh/monaco-editor@0.50.0/esm/vs/editor/editor.worker?worker';
import   JsonWorker from 'https://esm.sh/monaco-editor@0.50.0/esm/vs/language/json/json.worker?worker';
import    CssWorker from 'https://esm.sh/monaco-editor@0.50.0/esm/vs/language/css/css.worker?worker';
import   HtmlWorker from 'https://esm.sh/monaco-editor@0.50.0/esm/vs/language/html/html.worker?worker';
import     TSWorker from 'https://esm.sh/monaco-editor@0.50.0/esm/vs/language/typescript/ts.worker?worker';

self.monaco = Monaco;
self.MonacoEnvironment = {
  getWorker (_, label) { return {
    'css'        : new  CssWorker(),
    'less'       : new  CssWorker(),
    'scss'       : new  CssWorker(),
    'html'       : new HtmlWorker(),
    'json'       : new JsonWorker(),
    'javascript' : new   TSWorker(),
    'typescript' : new   TSWorker(),
  }[label] || EditorWorker() }
};

// 2. Die Preact Komponente
export default function Editor ({ content, config, options }) {
  let containerRef = useRef(null);
  let editorRef    = useRef(null);
  let activeFile   = ratcode.activeFile.value;
  
  // Init Monaco on 1st Render
  useEffect(() => {
    if (!containerRef.current) return;
    let { theme, ...restOptions } = config;
    editorRef.current = Monaco.editor.create(containerRef.current, {
      ...restOptions,
      value    : activeFile?.content  ?? '',
      language : activeFile?.language ?? 'plaintext',
    });
    ratcode.monaco = editorRef.current;
    // Set Theme
    ratcode.editor.updateTheme(theme);
    // Änderungen ins Signal schreiben (isDirty setzen)
    editorRef.current.onDidChangeModelContent(() => {
      let file = ratcode.activeFile.value;
      if (!file) return;
      file = { ...file, content: editorRef.current.getValue(), isDirty: true };
      // openFiles ebenfalls aktuell halten
      ratcode.openFiles.value = ratcode.openFiles.value.map(
        f => f.handle === file.handle ? file : f
      );
    });
    // Get all commands from the editor instance
    let monacoCommands = editorRef.current.getSupportedActions(); 
    console.log(monacoCommands);
    //
    return () => editorRef.current.dispose();
  }, []);
  
  // Handle Active File
  useEffect(() => {
    if (!editorRef.current || !activeFile) return;
    let current = editorRef.current.getValue();
    if (current !== activeFile.content) editorRef.current.setValue(activeFile.content);
    Monaco.editor.setModelLanguage(editorRef.current.getModel(), activeFile.language);
  }, [activeFile]);
  
  // Handle Options
  /*
  useEffect(() => {
    if (!editorRef.current || !options) return;
    let { theme, ...rest } = options;
    editorRef.current.updateOptions(rest);
  }, [options]);
  */
  
  // Handle Config
  /*
  useEffect(() => {
    if (!editorRef.current || !config) return;
    let { theme, ...rest } = config;
    editorRef.current.updateOptions(rest);
  }, [config]);
  */
  // Handle Config
  useEffect(() => {
    if (!editorRef.current) return;
    let { theme, ...rest } = config.$signal.value; // read the snapshot
    editorRef.current.updateOptions(rest);
  }, [config.$signal.value]); // ← now re-runs on any nested change
  
  //
  return html`
    <div id='editor'>
      ${!activeFile && html`<${Welcome}/>`}
      <div id='monaco-container' ref=${containerRef} style="display: ${activeFile ? 'block' : 'none'}"></div>
    </div>
  `;
  
};