// components/Browser.js

export default function Browser ({}) {
  return html`
    <div id='browser'>
      Browser
    </div>
  `;
};