// components/ToggleWithSignal.js

export default function ToggleWithSignal ({ label, signal, size }) {
  let onChange = value => signal.value = value;
  return html`<${Toggle} value=${signal.value} ...${{ label, onChange, size }} />`;
}