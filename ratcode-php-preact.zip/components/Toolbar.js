// components/Toolbar.js

export default function Toolbar ({}) {
  let items = ratcode.toolbar.items.value;
  return html`
    <div id='toolbar'>
      ${items.map( ({cmd, icon}) => html`<${Tap} cmd=${cmd}  icon=${icon} />`)}
    </div>
  `;
};