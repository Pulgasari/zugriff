// components/Modal.js

export default function Modal ({ children, id, title }) {
  return html`
    <div className='modal' id=${id}>
      <div className='inner'>
        <div className='aside'>
          <span>${title}</span>
          <div onClick=${() => ratcode.modal.value = null}>
            <${Icon} name='close' />
          </div>
        </div>
        <div className='main'>
          ${children}
        </div>
      </div>
    </div>
  `;
};