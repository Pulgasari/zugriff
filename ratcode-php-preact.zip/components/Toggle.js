// components/Toggle.js

export default function Toggle({ value = false, onChange, label, size='32' }) {
  let opacity = value ? '100%' : '50%';
  let icon    = value ? 'bx:toggle-right' : 'bx:toggle-left';
  let text    = label ? html`<span>${label}</span>` : '';
  let onClick = () => onChange && onChange(!value);

  return html`
    <div className='toggle' style=${{ opacity }} onClick=${onClick}>
      <${Icon} name=${icon} size=${size} />
      ${text}
    </div>
  `;
}