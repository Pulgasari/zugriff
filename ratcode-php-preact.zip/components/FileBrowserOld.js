// components/FileBrowser.js

import { useEffect, useState, useCallback } from 'preact/hooks';

export let filesSignal = signal([]);
let statusSignal       = signal('init');
let errorSignal        = signal(null);
let savedHandleSignal  = signal(null);

export default function FileBrowser ({}) {
  let files       = filesSignal.value;
  let status      = statusSignal.value;
  let errorMsg    = errorSignal.value;
  let savedHandle = savedHandleSignal.value;

  let ensureWritePermission = async () => {
    let handle = savedHandleSignal.peek();
    if (!handle) return false;
    let perm = await handle.queryPermission({ mode: 'readwrite' });
    if (perm === 'granted') return true;
    // Only now do we need a user gesture — this is called from a button click
    perm = await handle.requestPermission({ mode: 'readwrite' });
    return perm === 'granted';
  };
  let loadDirectoryContents = async (dirHandle) => {
    let entries = [];
    for await (let entry of dirHandle.values()) entries.push(entry);
    entries.sort((a,b) => a.kind === b.kind ? a.name.localeCompare(b.name) : a.kind === 'directory' ? -1 : 1);
    filesSignal.value        = entries;
    ratcode.files            = entries;
    ratcode.currentDirHandle = dirHandle;
    statusSignal.value       = 'ready';
  };
  /*
  useEffect(() => {
    if (statusSignal.peek() !== 'init') return; // ← skip re-init if already loaded
    let init = async () => {
      try {
        let handle = await ratcode.db.workspace.get('root-dir');
        if (!handle) { statusSignal.value = 'idle'; return; }
        savedHandleSignal.value = handle;
        let permission = await handle.queryPermission({ mode: 'readwrite' });
        if (permission === 'granted') await loadDirectoryContents(handle);
        else statusSignal.value = 'needs-restore';
      } catch (e) {
        console.error('Init-Fehler:', e);
        statusSignal.value = 'error';
        errorSignal.value  = 'Fehler beim Laden der gespeicherten Sitzung.';
      }
    };
    init();
  }, []);
  */
  useEffect(() => {
    if (statusSignal.peek() !== 'init') return;
    let init = async () => {
      try {
        let handle = await ratcode.db.workspace.get('root-dir');
        if (!handle) { statusSignal.value = 'idle'; return; }
        savedHandleSignal.value = handle;
        // Step 1: try read permission (persistent-friendly)
        let readPermission = await handle.queryPermission({ mode: 'read' });
        if (readPermission === 'prompt') readPermission = await handle.requestPermission({ mode: 'read' });
        if (readPermission !== 'granted') { statusSignal.value = 'needs-restore'; return; }
        // Step 2: upgrade to readwrite silently if already granted
        let writePermission = await handle.queryPermission({ mode: 'readwrite' });
        if (writePermission !== 'granted') {
          // Don't force prompt here — request lazily on first save instead
          console.info('[FS] read-only restore, write will be requested on first save');
        }
        await loadDirectoryContents(handle);
      } catch (e) {
        statusSignal.value = 'error';
        errorSignal.value  = 'Fehler beim Laden der gespeicherten Sitzung.';
      }
    };
    init();
  }, []);

  let openDirectory = async () => {
    errorSignal.value = null;
    try {
      let dirHandle = await window.showDirectoryPicker({ mode: 'readwrite' });
      await ratcode.db.workspace.set('root-dir', dirHandle);
      savedHandleSignal.value = dirHandle;
      await loadDirectoryContents(dirHandle);
    } catch (e) {
      if (e.name !== 'AbortError') {
        errorSignal.value  = 'Ordner konnte nicht geöffnet werden.';
        statusSignal.value = 'error';
      }
    }
  };
  /*
  let restoreDirectory = async () => {
    if (!savedHandleSignal.peek()) return;
    errorSignal.value = null;
    try {
      let perm = await savedHandleSignal.peek().requestPermission({ mode: 'readwrite' });
      if (perm === 'granted') await loadDirectoryContents(savedHandleSignal.peek());
      else errorSignal.value = `Zugriff auf "${savedHandleSignal.peek().name}" wurde verweigert.`;
    } catch (e) {
      statusSignal.value = 'error';
      errorSignal.value  = 'Berechtigungen konnten nicht wiederhergestellt werden.';
    }
  };
  */
  let restoreDirectory = async () => {
    let handle = savedHandleSignal.peek();
    if (!handle) return;
    errorSignal.value = null;
  
    try {
      let perm = await handle.requestPermission({ mode: 'readwrite' });
      if (perm === 'granted') {
        await loadDirectoryContents(handle);
        return;
      }
    } catch (e) {
      // requestPermission fehlgeschlagen → fallthrough to re-pick
    }
  
    // Fallback: user picks again — startIn hints at the same directory
    try {
      let newHandle = await window.showDirectoryPicker({ 
        mode    : 'readwrite',
        startIn : handle, // browser öffnet direkt den richtigen Ordner
      });
      await ratcode.db.workspace.set('root-dir', newHandle);
      savedHandleSignal.value = newHandle;
      await loadDirectoryContents(newHandle);
    } catch (e) {
      if (e.name !== 'AbortError') {
        errorSignal.value  = `Zugriff auf "${handle.name}" konnte nicht wiederhergestellt werden.`;
        statusSignal.value = 'error';
      }
    }
  };

  return html`
    <${Modal} id='filebrowser' title='File Browser'>

      <div class="filebrowser-header">
        <button onClick=${openDirectory} class="btn-primary">
          <${Icon} name="material-symbols:folder-open" />
          Neuen Ordner freigeben
        </button>
        ${status === 'needs-restore' && savedHandle && html`
          <button onClick=${restoreDirectory} class="btn-secondary btn-accent">
            <${Icon} name="material-symbols:folder-open" />
            "${savedHandle.name}" öffnen
          </button>
        `}
      </div>

      ${errorMsg && html`
        <div class="filebrowser-error">
          <${Icon} name="material-symbols:error-outline" size="16" />
          ${errorMsg}
        </div>
      `}

      <div class="filebrowser-body">
        ${status === 'init' && html`
          <div class="none">
            <${Icon} name="material-symbols:hourglass-empty" size="24" /><br/>
            Lade gespeicherte Sitzung…
          </div>
        `}
        ${status === 'needs-restore' && html`
          <div class="none">
            <${Icon} name="material-symbols:lock-outline" size="24" /><br/>
            Klicke auf "Wiederherstellen", um<br/>
            <strong>${savedHandle?.name}</strong> zu reaktivieren.
          </div>
        `}
        ${(status === 'ready' || status === 'idle') && html`
          ${files.length === 0
            ? html`
                <div class="none">
                  <${Icon} name="material-symbols:info" size="24" /><br/>
                  Kein Ordner geladen.
                </div>
              `
            : html`
                <ul class="tree-root">
                  ${files.map(entry => html`
                    <${TreeNode} key=${entry.name} entry=${entry} depth=${0} />
                  `)}
                </ul>
              `
          }
        `}
      </div>

    </${Modal}>
  `;
}