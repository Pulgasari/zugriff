// components/Settings.js (Modal)

const THEMES = ['ratcode-dark', 'ratcode-light', 'ratcode-oled', 'ratcode-dracula'];

let editorPickers = [
  { key: 'fontSize'         , options: [8, 9, 10, 11, 12, 13, 14] },
  { key: 'autoIndent'       , options: ["none", "advanced", "full", "brackets", "keep"] },
  { key: 'cursorBlinking'   , options: ['blink', 'smooth', 'phase', 'expand', 'solid'] },
  { key: 'cursorStyle'      , options: ['line', 'block', 'underline', 'line-thin', 'block-outline', 'underline-thin'] },
  { key: 'wordWrap'         , options: ["off", "on", "wordWrapColumn", "bounded"] },
  { key: 'wrappingStrategy' , options: ["simple", "advanced"] },
];
let editorToggles = [
  'contextmenu',
  'folding',
  'fontLigatures',
  'lineNumbers',
  'readOnly',
  'scrollBeyondLastLine',
  'showUnused',
  'wordBasedSuggestions',
//  'wordWrap'
];
let uiPickers = [
  { key: 'fileSizeFormat' , options: ["bytes", "chars", "formatted"] },
];
let uiToggles = [
  'disableAndroidKeyboard',
];


// Snippets
function uiPickerField({ key, options }) {
  let value = ratcode.config[key].value;
  return html`
    <div class="field settings-field">
      <label>${key}</label>
      <${Picker}
        callback=${v => ratcode.config[key].value = v}
        options=${options}
        value=${value}
      />
    </div>
  `;
}
function uiToggleField (key) {
  return html`
    <div>
      <${Toggle}
        label=${key}
        onChange=${() => ratcode.config[key].value = !ratcode.config[key].value}
        value=${ratcode.config[key].value}
      />
    </div>
  `;
}
function editorPickerField({ key, options }) {
  let value = ratcode.editor.config[key];
  return html`
    <div class="field settings-field">
      <label>${key}</label>
      <${Picker}
        callback=${v => ratcode.editor.config.$update({ [key]: v })}
        options=${options}
        value=${value}
      />
    </div>
  `;
}
function editorToggleField (key) {
  let raw     = ratcode.editor.config[key];
  let checked = raw === true || raw === 'on';

  return html`
    <div>
      <${Toggle}
        label=${key}
        onChange=${() => ratcode.editor.config.$toggle(key)}
        value=${checked}
      />
    </div>
  `;
}

export default function Settings ({}) {
  let editorThemes = ratcode.editor.themes;
  return html`
    <${Modal} id='settings' title='Settings'>
      <div className='section'>
        <h3>UI</h3>
        <${Dropdown}
          options=${THEMES}
          selected=${ratcode.config.theme.value}
          onChange=${event => ratcode.config.theme.value = event.currentTarget.value}
        />
        ${uiToggles.map(uiToggleField)}
        ${uiPickers.map(uiPickerField)}
      </div>
      <div className='section'>
        <h3>Editor</h3>
        <${Dropdown}
          options=${editorThemes}
          selected=${ratcode.editor.config.theme}
          onChange=${event => ratcode.editor.updateTheme(event.currentTarget.value)}
        />
        ${editorToggles.map(editorToggleField)}
        ${editorPickers.map(editorPickerField)}
      </div>
    </${Modal}>
  `;
};