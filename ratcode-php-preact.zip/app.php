<?php

// Server Lib Autoloader
require_once __DIR__ . '/../lib/php/autoloader.php';

// Show Errors
if (WTF::get('errors') === 'true') {
  ini_set('display_errors', '1');
  ini_set('display_startup_errors', '1');
  error_reporting(E_ALL);
}

$appcolor  = '#000000';
$logo      = file_get_contents('logo.svg');
$theme     = WTF::cookie('theme') ?: 'ratcode-oled';
//$anticache = '';
$anticache = WTF::get('ts') === 'off' ? '' : '?v=' . time();
// 10.23.1
// https://esm.sh/htm@3.1.1
?>

<!DOCTYPE html>
<html lang='de' data-theme='<?=$theme?>'>
<head>
  <meta charset='UTF-8'>
  <link rel='manifest' href='/manifest.json'>
  <meta name='apple-mobile-web-app-capable' content='yes'>
  <meta name='viewport' content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  
  <!-- AppColor -->
  <meta name="apple-mobile-web-app-status-bar-style" content="<?=$appcolor?>">
  <meta name="msapplication-TileColor" content="<?=$appcolor?>">
  <meta name="theme-color" content="<?=$appcolor?>"/>
  
  <!-- Title -->
  <meta name='apple-mobile-web-app-title' content='Ratcode'>
  <title>Ratcode</title>
  
  <!-- CSS Stylesheets -->
  <link rel='stylesheet' href='app.css?v=<?=time()?>' />
  <link rel='stylesheet' href='https://esm.sh/monaco-editor@0.50.0?css' id='monaco-css' />
  
  <!-- JS ImportMap -->
  <script type="importmap">
		{ "imports": {
			"bunker"          : "https://cdn.ratcode.dev/js/bunker.js",
		  "iconify"         : "https://code.iconify.design/iconify-icon/3.0.0/iconify-icon.min.js",
		  "monaco-themes"   : "https://unpkg.com/monaco-themes/dist/index.js",
			"preact"          : "https://esm.sh/preact@10.19.6",
			"preact/"         : "https://esm.sh/preact@10.19.6/",
			"htm/preact"      : "https://esm.sh/htm@3.1.1/preact?deps=preact@10.19.6",
			"@preact/signals" : "https://esm.sh/@preact/signals@1.3.0?deps=preact@10.19.6",
			"preact-x"        : "https://cdn.ratcode.dev/js/preact-x.js",
			"ratlib"          : "https://cdn.ratcode.dev/js/ratlib.js"
		}}
	</script>
	<script src='https://code.iconify.design/iconify-icon/3.0.0/iconify-icon.min.js'></script>
</head>

<body>
  <div id='app'>
    <div id='nothing'>
      <?=$logo?>
      <iconify-icon icon='svg-spinners:bars-scale-middle' style='color: var(--accent, currentcolor);'></iconify-icon>
    </div>
  </div>
  <script type='module'>
    /*
    window.onload = () => { 'use strict';
      if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js');
    };
    */
  
    if ('serviceWorker' in navigator) {
      try {
        let { installing, waiting } = await navigator.serviceWorker.register('/sw.js', { type: 'module' });
        if (installing || waiting) await new Promise( resolve => navigator.serviceWorker.addEventListener('controllerchange', resolve) );
        // Done
        console.log('Service Worker registered successfully.');
      } catch (error) {
        console.error('Service Worker registration failed:', error);
      }
    }
    else { console.warn('Service Workers are not supported in this browser.'); }
  </script>
  <script type='module' src='app.js<?=$anticache?>'></script>
</body>
<html>