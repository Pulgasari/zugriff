const CACHE_VERSION = 'v1';
const APP_SHELL_CACHE = `app-shell-${CACHE_VERSION}`;
const RUNTIME_CACHE = `runtime-${CACHE_VERSION}`;

const START_URL = '/';
const OFFLINE_URL = '/offline.html';

const APP_SHELL_ASSETS = [
  START_URL,
  '/manifest.json',
  '/app.css',
  '/app.js',
  '/logo.svg',
  OFFLINE_URL,
];

function importStatement(name, disableCache = false) {
  let str = `import ${name} from '/components/${name}.js`;
  if (disableCache) str += `?v=${Date.now()}`;
  return `${str}';`;
}

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(APP_SHELL_CACHE);
    // Cache what exists without failing install on missing optional files.
    await Promise.allSettled(
      APP_SHELL_ASSETS.map(async (url) => {
        const req = new Request(url, { cache: 'reload' });
        const res = await fetch(req);
        if (res.ok) await cache.put(req, res);
      })
    );
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(
      keys
        .filter((key) => ![APP_SHELL_CACHE, RUNTIME_CACHE].includes(key))
        .map((key) => caches.delete(key))
    );
    await self.clients.claim();
  })());
});

async function handleNavigation(event) {
  const request = event.request;
  const runtime = await caches.open(RUNTIME_CACHE);

  try {
    const networkResponse = await fetch(request);
    if (networkResponse && networkResponse.ok) {
      runtime.put(request, networkResponse.clone());
    }
    return networkResponse;
  } catch (_) {
    const cachedPage = await caches.match(request);
    if (cachedPage) return cachedPage;

    const startPage = await caches.match(START_URL);
    if (startPage) return startPage;

    const offlinePage = await caches.match(OFFLINE_URL);
    if (offlinePage) return offlinePage;

    return new Response('Offline', {
      status: 503,
      statusText: 'Service Unavailable',
      headers: { 'Content-Type': 'text/plain' },
    });
  }
}

async function handleJavaScriptTransform(event) {
  const request = event.request;
  const url = new URL(request.url);
  const currentFile = url.pathname.split('/').pop().replace('.js', '');

  try {
    const response = await fetch(request);
    if (!response.ok) return response;

    let code = await response.text();
    const imports = [];

    // Auto-import signal.
    if (/signal\s*\(/.test(code) && !code.includes('import { signal }')) {
      imports.push("import { signal } from '@preact/signals';");
    }

    // Auto-import local components used as <${Component}>.
    const matches = [...code.matchAll(/<\$\{([A-Z]\w+)/g)];
    if (matches.length > 0) {
      const components = [...new Set(matches.map((m) => m[1]))];
      for (const name of components) {
        if (name === currentFile) continue;
        if (!code.includes(`import ${name}`)) {
          imports.push(importStatement(name, false));
        }
      }
    }

    if (imports.length > 0) {
      code = `${imports.join('\n')}\n\n${code}`;
    }

    return new Response(code, {
      status: 200,
      statusText: 'OK',
      headers: {
        'Content-Type': 'application/javascript; charset=utf-8',
        'Cache-Control': 'no-cache',
      },
    });
  } catch (error) {
    return fetch(request);
  }
}

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);

  // Installability-critical: ensure navigations have offline-capable handling.
  if (request.mode === 'navigate') {
    event.respondWith(handleNavigation(event));
    return;
  }

  // Keep your existing JS auto-import transform for same-origin JS files.
  if (url.origin === self.location.origin && url.pathname.endsWith('.js')) {
    event.respondWith(handleJavaScriptTransform(event));
    return;
  }

  // Lightweight runtime caching for same-origin static assets.
  if (url.origin === self.location.origin) {
    event.respondWith((async () => {
      const cached = await caches.match(request);
      if (cached) return cached;

      try {
        const networkResponse = await fetch(request);
        if (networkResponse && networkResponse.ok) {
          const runtime = await caches.open(RUNTIME_CACHE);
          runtime.put(request, networkResponse.clone());
        }
        return networkResponse;
      } catch (_) {
        return cached || Response.error();
      }
    })());
  }
});
