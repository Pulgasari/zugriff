// js/editor.js
/*
https://microsoft.github.io/monaco-editor/docs.html#interfaces/editor_editor_api.editor.IStandaloneEditorConstructionOptions.html
https://github.com/brijeshb42/monaco-themes
*/

import { deepSignalWithStorage, signalWithCookie } from 'preact-x';

//import monacoThemes from '/json/monaco-themes.json' with { type: 'json' };

// Data

let MONACO_THEMES = {
  "active4d"                : "Active4D",
  "all-hallows-eve"         : "All Hallows Eve",
  "amy"                     : "Amy",
  "birds-of-paradise"       : "Birds of Paradise",
  "blackboard"              : "Blackboard",
  "brilliance-black"        : "Brilliance Black",
  "brilliance-dull"         : "Brilliance Dull",
  "chrome-devtools"         : "Chrome DevTools",
  "clouds-midnight"         : "Clouds Midnight",
  "clouds"                  : "Clouds",
  "cobalt"                  : "Cobalt",
  "cobalt2"                 : "Cobalt2",
  "dawn"                    : "Dawn",
  "dracula"                 : "Dracula",
  "dreamweaver"             : "Dreamweaver",
  "eiffel"                  : "Eiffel",
  "espresso-libre"          : "Espresso Libre",
  "github-dark"             : "GitHub Dark",
  "github-light"            : "GitHub Light",
  "github"                  : "GitHub",
  "idle"                    : "IDLE",
  "katzenmilch"             : "Katzenmilch",
  "kuroir-theme"            : "Kuroir Theme",
  "lazy"                    : "LAZY",
  "magicwb--amiga-"         : "MagicWB (Amiga)",
  "merbivore-soft"          : "Merbivore Soft",
  "merbivore"               : "Merbivore",
  "monokai-bright"          : "Monokai Bright",
  "monokai"                 : "Monokai",
  "night-owl"               : "Night Owl",
  "nord"                    : "Nord",
  "oceanic-next"            : "Oceanic Next",
  "pastels-on-dark"         : "Pastels on Dark",
  "slush-and-poppies"       : "Slush and Poppies",
  "solarized-dark"          : "Solarized-dark",
  "solarized-light"         : "Solarized-light",
  "spacecadet"              : "SpaceCadet",
  "sunburst"                : "Sunburst",
  "textmate--mac-classic-"  : "Textmate (Mac Classic)",
  "tomorrow-night-blue"     : "Tomorrow-Night-Blue",
  "tomorrow-night-bright"   : "Tomorrow-Night-Bright",
  "tomorrow-night-eighties" : "Tomorrow-Night-Eighties",
  "tomorrow-night"          : "Tomorrow-Night",
  "tomorrow"                : "Tomorrow",
  "twilight"                : "Twilight",
  "upstream-sunburst"       : "Upstream Sunburst",
  "vibrant-ink"             : "Vibrant Ink",
  "xcode-default"           : "Xcode_default",
  "zenburnesque"            : "Zenburnesque",
  "iplastic"                : "iPlastic",
  "idlefingers"             : "idleFingers",
  "krtheme"                 : "krTheme",
  "monoindustrial"          : "monoindustrial",
};
let NATIVE_THEMES = ['vs', 'vs-dark', 'hc-black', 'hc-light'];
let themes        = [...NATIVE_THEMES, ...Object.keys(MONACO_THEMES)];
let themeCache    = new Set(); //

// Signals

let content = signal(`// Lade eine Datei...`);

let config  = deepSignalWithStorage({ key: 'ratcode-editor-config', value: {
  autoIndent           : 'none',
  automaticLayout      : true,
  contextmenu          : false,
  cursorBlinking       : 'blink',
  cursorStyle          : 'line',
  cursorWidth          : 2,
  disableLayerHinting  : true,
  dragAndDrop          : true,
  folding              : true,
  fontLigatures        : true,
  fontSize             : 10,
  letterSpacing        : 0,
  lineNumbers          : 'on',
  lineNumbersMinChars  : 3,
  links                : true,
  readOnly             : false,
  renderLineHighlight  : 'none',
  scrollBeyondLastLine : false,
  showUnused           : true,
  tabSize              : 2,
  wordBasedSuggestions : false,
  wordWrap             : 'off',
  wrappingStrategy     : 'simple',
  theme                : 'dracula',
  minimap : { // https://microsoft.github.io/monaco-editor/docs.html#interfaces/editor_editor_api.editor.IEditorMinimapOptions.html
    enabled          : false,
    renderCharacters : false,
    side             : 'right',
  }
}});

// Methods

let updateConfig = (obj, target = config) => {
  for (let [k, v] of Object.entries(obj)) {
    if (v !== null && typeof v === 'object' && !Array.isArray(v)) {
      updateConfig(v, target[k]); // recurse into nested objects
    } else {
      target[k] = v;
    }
  }
};
let toggleConfig = (key, target = config) => {
  if (key.includes('.')) {
    let [parent, ...rest] = key.split('.');
    toggleConfig(rest.join('.'), target[parent]);
    return;
  }
  let v = target[key];
  target[key] = typeof v === 'boolean' ? !v
              : v === 'on'             ? 'off'
              : v === 'off'            ? 'on'
              : v; // unknown type → no-op
};

let updateTheme = async (themeKey) => {
  let M = self.monaco; // Monaco-Namespace, in Editor.js als self.monaco = Monaco gesetzt

  if (NATIVE_THEMES.includes(themeKey)) {
    M.editor.setTheme(themeKey);
  } 
  else {
    if (!themeCache.has(themeKey)) {
      let themeName = MONACO_THEMES[themeKey];
      let url       = `https://unpkg.com/monaco-themes/themes/${themeName}.json`;
      let themeData = await fetch(url).then( r => r.json() );
      M.editor.defineTheme(themeKey, themeData);
      themeCache.add(themeKey);
    }
    M.editor.setTheme(themeKey);
  }

  //updateOption('theme', themeKey);
  config.theme = themeKey;
};

/*
let toggleFolding = () => toggleOption('folding');
let toggleTheme   = () => updateOption('theme', options.value.theme === 'vs-dark' ? 'vs-light' : 'vs-dark' );
*/

// Final Object

let editor = {
  config, updateConfig, toggleConfig,
  content, 
//  options, updateOption, toggleOption, updateTheme,
//  toggleFolding, toggleTheme,
  themes
  //exec    : id => editor.trigger('source', id),
};

export default editor;



/*
// Example: Get current text
const val = editorInstance.getValue();

// Example: Insert text at current position
editorInstance.trigger('keyboard', 'type', { text: 'Hello World!' });

ratcode.editor.type = text => editorInstance?.trigger('keyboard', 'type', { text });
*/