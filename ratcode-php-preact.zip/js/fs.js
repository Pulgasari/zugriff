// js/fs.js

export let fs = {
  async getSavedRoot () {
    return await ratcode.db.workspace.get('root-dir');
  },

  async setRoot (handle) {
    await ratcode.db.workspace.set('root-dir', handle);
    return handle;
  },
  
  async clearAll () {
    await ratcode.db.workspace.clear();
  },
  
  async clearRoot () {
    await ratcode.db.workspace.delete('root-dir');
  },

  async ensureReadPermission (handle) {
    let permission = await handle.queryPermission({ mode: 'read' });
    if (permission === 'prompt') {
      permission = await handle.requestPermission({ mode: 'read' });
    }
    //fs.setRoot(handle);
    return permission === 'granted';
  },

  async ensureWritePermission (handle) {
    let permission = await handle.queryPermission({ mode: 'readwrite' });
    if (permission !== 'granted') {
      permission = await handle.requestPermission({ mode: 'readwrite' });
    }
    //fs.setRoot(handle);
    return permission === 'granted';
  },

  async readDir (handle) {
    let entries = [];
    for await (let entry of handle.values()) entries.push(entry);
    return entries.sort((a,b) =>
      a.kind === b.kind
        ? a.name.localeCompare(b.name)
        : a.kind === 'directory' ? -1 : 1
    );
  }
};

export default fs;