// js/commands.js

// Helpers
let executeMonacoAction  = id    => ratcode.monaco?.getAction(id)?.run();
let executeMonacoTrigger = id    => ratcode.monaco?.trigger('keyboard', id, null);
let updateEditorOption   = (k,v) => ratcode.editor.updateOption(k, v);

let commands = new Map ([
  // UI
  [ 'browser:toggle'     , { name: 'Toggle Browser'     , exec: () => ratcode.toggleSignal(ratcode.config.showBrowser)  }],
  [ 'keyboard:toggle'    , { name: 'Toggle Keyboard'    , exec: () => ratcode.toggleSignal(ratcode.config.showKeyboard) }],
  [ 'toolbar:toggle'     , { name: 'Toggle Toolbar'     , exec: () => ratcode.toggleSignal(ratcode.config.showToolbar)  }],
  [ 'filebrowser:toggle' , { name: 'Toggle FileBrowser' , exec: () => ratcode.toggleModal('filebrowser') }],
  [ 'commands:toggle'    , { name: 'Toggle Commands'    , exec: () => ratcode.toggleModal('commands')    }],
  [ 'plugins:toggle'     , { name: 'Toggle Plugins'     , exec: () => ratcode.toggleModal('plugins')     }],
  [ 'settings:toggle'    , { name: 'Toggle Settings'    , exec: () => ratcode.toggleModal('settings')    }],

  // File
  [ 'file:close'    , { name: 'Close File'    , exec: () => {} }],
  [ 'file:save'     , { name: 'Save File'     , exec: () => {} }],
  [ 'file:saveAll'  , { name: 'Save All'      , exec: () => {} }],
  
  // Editor – Cursor
  [ 'editor:cursor:redo'  , { name: 'Editor: Redo' , exec: () => executeMonacoAction('cursorRedo') }],
  [ 'editor:cursor:undo'  , { name: 'Editor: Undo' , exec: () => executeMonacoAction('cursorUndo') }],
  
  // Editor – History
  [ 'editor:redo'   , { name: 'Redo' , exec: () => ratcode.monaco?.getModel()?.redo() }],
  [ 'editor:undo'   , { name: 'Undo' , exec: () => ratcode.monaco?.getModel()?.undo() }],

  // Editor – Clipboard
  [ 'editor:copy'   , { name: 'Copy'  , exec: () => executeMonacoAction('editor.action.clipboardCopyAction')  }],
  [ 'editor:cut'    , { name: 'Cut'   , exec: () => executeMonacoAction('editor.action.clipboardCutAction')   }],
  [ 'editor:paste'  , { name: 'Paste' , exec: () => executeMonacoAction('editor.action.clipboardPasteAction') }],

  // Editor – Selection
  [ 'editor:selectAll'            , { name: 'Select All'        , exec: () => executeMonacoTrigger('editor.action.selectAll')                   }],
  [ 'editor:selectLine'           , { name: 'Select Line'       , exec: () => executeMonacoAction('editor.action.smartSelect.expand')     }],
  [ 'editor:expandSelection'      , { name: 'Expand Selection'  , exec: () => executeMonacoAction('editor.action.smartSelect.expand')     }],
  [ 'editor:shrinkSelection'      , { name: 'Shrink Selection'  , exec: () => executeMonacoAction('editor.action.smartSelect.shrink')     }],
  [ 'editor:addCursorAbove'       , { name: 'Add Cursor Above'  , exec: () => executeMonacoAction('editor.action.insertCursorAbove')      }],
  [ 'editor:addCursorBelow'       , { name: 'Add Cursor Below'  , exec: () => executeMonacoAction('editor.action.insertCursorBelow')      }],
  [ 'editor:selectNextOccurrence' , { name: 'Select Next Match' , exec: () => executeMonacoAction('editor.action.addSelectionToNextFindMatch') }],

  // Editor – Lines
  [ 'editor:deleteLines'        , { name: 'Delete Line'          , exec: () => executeMonacoAction('editor.action.deleteLines')            }],
  [ 'editor:duplicateLine'      , { name: 'Duplicate Line Down'  , exec: () => executeMonacoAction('editor.action.copyLinesDownAction')    }],
  [ 'editor:moveLineUp'         , { name: 'Move Line Up'         , exec: () => executeMonacoAction('editor.action.moveLinesUpAction')      }],
  [ 'editor:moveLineDown'       , { name: 'Move Line Down'       , exec: () => executeMonacoAction('editor.action.moveLinesDownAction')    }],
  [ 'editor:indentLines'        , { name: 'Indent'               , exec: () => executeMonacoAction('editor.action.indentLines')            }],
  [ 'editor:outdentLines'       , { name: 'Outdent'              , exec: () => executeMonacoAction('editor.action.outdentLines')           }],
  [ 'editor:sortLinesAsc'       , { name: 'Sort Lines Asc'       , exec: () => executeMonacoAction('editor.action.sortLinesAscending')     }],
  [ 'editor:sortLinesDesc'      , { name: 'Sort Lines Desc'      , exec: () => executeMonacoAction('editor.action.sortLinesDescending')    }],
  [ 'editor:joinLines'          , { name: 'Join Lines'           , exec: () => executeMonacoAction('editor.action.joinLines')              }],
  [ 'editor:commentLine'        , { name: 'Toggle Line Comment'  , exec: () => executeMonacoAction('editor.action.commentLine')            }],
  [ 'editor:commentBlock'       , { name: 'Toggle Block Comment' , exec: () => executeMonacoAction('editor.action.blockComment')           }],

  // Editor – Folding
  [ 'editor:fold'               , { name: 'Fold'                 , exec: () => executeMonacoAction('editor.fold')                          }],
  [ 'editor:unfold'             , { name: 'Unfold'               , exec: () => executeMonacoAction('editor.unfold')                        }],
  [ 'editor:foldAll'            , { name: 'Fold All'             , exec: () => executeMonacoAction('editor.foldAll')                       }],
  [ 'editor:unfoldAll'          , { name: 'Unfold All'           , exec: () => executeMonacoAction('editor.unfoldAll')                     }],
  [ 'editor:foldRecursive'      , { name: 'Fold Recursive'       , exec: () => executeMonacoAction('editor.foldRecursive')                 }],

  // Editor – Search
  [ 'editor:find'               , { name: 'Find'                 , exec: () => executeMonacoAction('actions.find')                          }],
  [ 'editor:findReplace'        , { name: 'Find & Replace'       , exec: () => executeMonacoAction('editor.action.startFindReplaceAction')  }],
  [ 'editor:findNext'           , { name: 'Find Next'            , exec: () => executeMonacoAction('editor.action.nextMatchFindAction')     }],
  [ 'editor:findPrev'           , { name: 'Find Previous'        , exec: () => executeMonacoAction('editor.action.previousMatchFindAction') }],

  // Editor – Code
  [ 'editor:format'             , { name: 'Format Document'      , exec: () => executeMonacoAction('editor.action.formatDocument')   }],
  [ 'editor:formatSelection'    , { name: 'Format Selection'     , exec: () => executeMonacoAction('editor.action.formatSelection')  }],
  [ 'editor:goToDefinition'     , { name: 'Go to Definition'     , exec: () => executeMonacoAction('editor.action.revealDefinition') }],
  [ 'editor:rename'             , { name: 'Rename Symbol'        , exec: () => executeMonacoAction('editor.action.rename')           }],
  [ 'editor:quickFix'           , { name: 'Quick Fix'            , exec: () => executeMonacoAction('editor.action.quickFix')         }],

  // Editor – View/Options
  [ 'editor:wordWrap:toggle'    , { name: 'Toggle WordWrap'       , exec: () => ratcode.editor.toggleOption('wordWrap')    }],
  [ 'editor:lineNumbers:toggle' , { name: 'Toggle LineNumbers'    , exec: () => ratcode.editor.toggleOption('lineNumbers') }],
  [ 'editor:minimap:toggle'     , { name: 'Toggle MiniMap'        , exec: () => ratcode.editor.toggleOption('minimap')     }],
  [ 'editor:fontSize:increase'  , { name: 'FontSize + (increase)' , exec: () => ratcode.editor.updateOption('fontSize', ratcode.editor.options.value.fontSize + 1) }],
  [ 'editor:fontSize:decrease'  , { name: 'FontSize – (decrease)' , exec: () => ratcode.editor.updateOption('fontSize', ratcode.editor.options.value.fontSize - 1) }],
]);


export default commands;