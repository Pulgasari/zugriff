// ratcode.js

import { signalWithCookie } from 'preact-x';
import BunkerDB from 'bunker';
import commands from '/js/commands.js';
import editor   from '/js/editor.js';

//////////////////// CONSTANTS ////////////////////

//
const BUNKER_DB_NAME = 'ratcode';

// Config Defaults
const DEFAULT_UI_FONTSIZE = 12;
const DEFAULT_UI_THEME    = 'ratcode-dracula';

////////////// GLOBAL RATCODE OBJECT //////////////

let methods = {
  closeModal   : ()  => ratcode.modal.value = null,
  openModal    : id  => ratcode.modal.value = id,
  toggleModal  : id  => ratcode.modal.value = (ratcode.modal.value === id) ? null : id,
  toggleSignal : sig => sig.value = !sig.value,
};

let ratcode = { commands, editor, ...methods };

// UI Configuration, Panel-States etc.
ratcode.config = {
  disableAndroidKeyboard : signalWithCookie(true, 'disableAndroidKeyboard'),
  fileSizeFormat         : signalWithCookie('formatted', 'fileSizeFormat'),
  fontSize               : signalWithCookie(DEFAULT_UI_FONTSIZE, 'fontSize'),
  theme                  : signalWithCookie(DEFAULT_UI_THEME, 'theme'),
  showBrowser            : signalWithCookie(false, 'showBrowser'),
  showKeyboard           : signalWithCookie(true, 'showKeyboard'),
  showStatubar           : signalWithCookie(true, 'showStatubar'),
  showToolbar            : signalWithCookie(true, 'showToolbar'),
};

// Database (IndexedDB via Bunker.js)
ratcode.db = new BunkerDB (BUNKER_DB_NAME);

// FileList
ratcode.openFiles  = signal([]);
ratcode.activeFile = signal(null);

// Toolbar
ratcode.toolbar = {
  items : signal([
    { cmd: 'editor:copy'         , icon: 'copy'            },
    { cmd: 'editor:cut'          , icon: 'cut'             },
    { cmd: 'editor:paste'        , icon: 'paste'           },
    { cmd: 'editor:selectAll'    , icon: 'select-all'      },
    { cmd: ''                    , icon: 'copy-lines-down' },
    { cmd: ''                    , icon: 'copy-lines-up'   },
    { cmd: 'editor:moveLineDown' , icon: 'move-lines-down' },
    { cmd: 'editor:moveLineUp'   , icon: 'move-lines-up'   },
    { cmd: 'editor:joinLines'    , icon: 'join-lines'      },
    { cmd: ''                    , icon: 'split-line'      },
    { cmd: 'editor:sortLinesAsc' , icon: 'sort-lines'      },
  ]),
};

//
ratcode.modal  = signal(null);
ratcode.exec   = cmd => ratcode.commands.get(cmd)?.exec();
ratcode.modals = {};
ratcode.panels = {};
ratcode.monaco = null; // binding in components/Editor.js



export { ratcode };
export default ratcode;


// Methods
export let loadFile = async (filePath) => {
  try {
    let response = await fetch(filePath);
    let text     = await response.text();
    ratcode.activeFileContent.value = text; 
  } catch (err) {
    console.error("Konnte Datei nicht laden:", err);
  }
};
